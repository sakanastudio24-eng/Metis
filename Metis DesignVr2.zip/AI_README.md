# AI_README — Metis Extension: Complete 1-to-1 Replication Guide

> **Purpose:** This file is written for an AI code generator. Every sentence is a specification. Read it in full before writing a single line. Nothing here is aspirational — it describes the exact, implemented design.

---

## 0. QUICK ORIENTATION

**What this is:** A Chrome extension UI prototype built in React + Tailwind v4. It is mounted at `/src/app/App.tsx` and the entire UI lives inside one exported component: `MetisExtension` from `/src/app/components/MetisExtension.tsx`.

**What it does:** Scans a web page for cost inefficiencies and presents them across a 3-state progressive disclosure flow: Tab Button → Mini Panel → Full Panel → Full Report Modal → Plus Upgrade Modal.

**Tech stack:**
```
React 18 (hooks only, no classes)
Tailwind CSS v4
motion/react  → import { motion, AnimatePresence } from "motion/react"
lucide-react  → all icons
sonner        → import { toast } from "sonner"
TypeScript
```

**File map:**
```
/src/app/App.tsx                          Root mount (do not change)
/src/app/components/MetisExtension.tsx    ENTIRE UI — 3756 lines, 17 sections
/src/app/types/metis.types.ts             TypeScript interfaces
/src/app/data/metis-mock-data.ts          All constants and mock data
/src/app/lib/scoring.ts                   Pure scoring engine
/src/styles/fonts.css                     Google Fonts import
/src/styles/theme.css                     CSS tokens (do not modify)
/guidelines/MetisStyleGuide.md            Full design token reference
```

---

## 1. DESIGN TOKENS — MEMORISE THESE

Never hardcode colours that aren't listed here. Never use Tailwind colour classes for brand values — use inline `style`.

```ts
// Exported from /src/app/data/metis-mock-data.ts
METIS_RED = "#dc5e5e"  // Brand red: CTA buttons, logo mark, Plus accents
DARK_BG   = "#0c1623"  // Deepest layer: app root, modal backdrops, tooltips
PANEL_BG  = "#111d2b"  // Panel layer: mini + full side panels
```

**Risk tier colours** — computed by `computeMetrics()`:
```
score ≥ 80  → riskColor "#ef4444"  riskBg "rgba(239,68,68,0.2)"   riskLabel "High Risk"
score ≥ 60  → riskColor "#f97316"  riskBg "rgba(249,115,22,0.2)"  riskLabel "Moderate Risk"
score ≥ 40  → riskColor "#eab308"  riskBg "rgba(234,179,8,0.2)"   riskLabel "Low Risk"
score < 40  → riskColor "#22c55e"  riskBg "rgba(34,197,94,0.2)"   riskLabel "Minimal Risk"
```

**White opacity stack** — all text on dark backgrounds uses `rgba(255,255,255,X)`:
```
Full white (headings, bold values)           → color: "white"
/70  Primary body, tooltips                  → "rgba(255,255,255,0.70)"
/60  Secondary body, quick insight           → "rgba(255,255,255,0.60)"
/55  Form labels, issue titles               → "rgba(255,255,255,0.55)"
/50  Session cost label, muted body          → "rgba(255,255,255,0.50)"
/45  Issue descriptions                      → "rgba(255,255,255,0.45)"
/40  Icon colours, panel subtitle            → "rgba(255,255,255,0.40)"
/35  Scanning text, profile email, URL       → "rgba(255,255,255,0.35)"
/30  Section labels (UPPERCASE), status text → "rgba(255,255,255,0.30)"
/28  Report subheadings                      → "rgba(255,255,255,0.28)"
/25  Rank numbers, stack category labels     → "rgba(255,255,255,0.25)"
/20  Footer branding, disclaimer text        → "rgba(255,255,255,0.20)"
/18  Score ring track stroke                 → "rgba(255,255,255,0.18)"
/15  Locked "—" in comparison table          → "rgba(255,255,255,0.15)"
```

**Surface backgrounds** (always inline style, never Tailwind bg-* colour classes):
```
rgba(255,255,255,0.04)  Card row on dark bg
rgba(255,255,255,0.05)  Quick insight box
rgba(255,255,255,0.06)  Stack chips, form select bg
rgba(255,255,255,0.07)  Card hover on dark bg, panel border
rgba(255,255,255,0.03)  Report section bg, refined output inner
rgba(255,255,255,0.02)  Issue card body
rgba(220,94,94,0.08)    Plus / refined output bg
rgba(220,94,94,0.06)    Baseline row in scale table, Plus mental model
```

**Semantic accents:**
```
#4ade80   green-400   Savings badges, ✓ checks
#a5b4fc   indigo-300  Scale projection value, Vercel badge
#10a37f   OpenAI green — AI badge text
#6366f1   indigo-500  Session cost live dot, WhatJustHappened TTI event
#60a5fa   blue-400    Export PDF button
#ffd700   gold        Trophy icon, "Fix First" badge
```

---

## 2. TYPOGRAPHY — EXACT RULES

**Fonts:** Jua (display/numerics) + Inter (everything else). Imported in `/src/styles/fonts.css`. Always applied via inline `style={{ fontFamily: "Jua, sans-serif" }}` or `style={{ fontFamily: "Inter, sans-serif" }}`.

**NEVER use Tailwind text-* size classes or font-* weight classes** unless overriding base styles. Use inline `fontSize` (number, in px) and `fontWeight` always.

```
Jua font usage (numbers, titles, wordmark):
  42px  Score number in Full Report overview
  36px  Upgrade modal price
  28px  Score number in full panel header
  24px  "Welcome to Metis+" success heading
  22px  Upgrade modal heading "Stop guessing. Start fixing."
  18px  "M" in full panel header
  16px  "M" in full report modal header; refined output cost value
  15px  Cost range in report overview; session cost (non-compact)
  14px  Panel title "Metis" / "Metis Scan"; "Metis+" badge; avatar price
  13px  Session cost (compact)
  12px  Cost row total; traffic slider value label
  11px  Scale row value; WhatJustHappened values; refined output header value
  10px  WhatJustHappened event values

Inter font usage (body, labels, everything else):
  13px  Profile dropdown name; upgrade CTA
  12px  Standard body — issue titles, cost row labels, button text
  11px  Small body — quick insight, descriptions, section subheadings
  10px  Tiny — root cause/fix labels, scale table labels, footer
   9px  Micro — severity badges, savings badges, stack detection labels
   8px  Nano — priority rank numbers, "Fix First" badge, billing tags
```

**Font weights (Inter only):**
```
400  Body text, descriptions
500  Default button (set by theme.css globally)
600  Section labels, issue titles, form labels, badge text (font-semibold)
700  Panel title, score numbers, cost values, CTA buttons (font-bold)
```

**Letter spacing:**
- Section labels (UPPERCASE): `letterSpacing: "0.1em"`
- ROOT CAUSE / FIX labels: `letterSpacing: "0.05em"`
- Report footer "THE METIS WAY": `letterSpacing: "0.06em"`
- Free/Plus columns "FREE" / "PLUS": `letterSpacing: "0.08em"`

---

## 3. COMPONENT TREE & STATE

```
MetisExtension  (root, exported, all state lives here)
│  State:
│    mode: PanelMode           "idle" | "mini" | "full"
│    showReport: boolean        Full Report modal
│    showPlus: boolean          Plus Upgrade modal
│    isPlusUser: boolean        Tier gate — false by default
│    isHovered: boolean         Tab button hover (for tooltip)
│    inputs: AccuracyInputs     The ONLY mutable scoring data
│
│  Derived (every render, no useMemo):
│    metrics = computeMetrics(inputs)  → MetisMetrics
│
├── AnimatePresence (mode === "idle")
│   └── TabButton (motion.div + motion.button)
│
├── AnimatePresence (mode === "mini")
│   └── motion.div [288px, fixed right-0 top-0 bottom-0]
│       └── MiniPanelContent
│           ├── Header
│           ├── AnimatePresence mode="wait" (loading → content)
│           │   ├── LoadingScreen  (1100ms)
│           │   └── Content (Score, QuickInsight, SessionCostBlock, Issues, Stack)
│           └── Footer (WhatJustHappened, CTA buttons)
│
├── AnimatePresence (mode === "full")
│   ├── Backdrop (motion.div, z-40, blur(3px))
│   └── motion.div [410px, fixed right-5 top-5 bottom-5]
│       └─��� FullPanelContent
│           ├── Header
│           ├── AnimatePresence mode="wait" (loading → content)
│           │   ├── LoadingScreen (1100ms)
│           │   └── Content (Score, Issues, Stack, Premium/Plus)
│           └── Footer (stack badges, CTA buttons)
│
├── AnimatePresence (showReport === true)
│   └── FullReportModal  (7 sections, z-[90]/z-[100])
│       ├── Backdrop (blur(16px))
│       ├── Header
│       ├── Body (AnimatePresence: loading 900ms → 7 sections)
│       └── Footer (Copy + Export PDF)
│
└── AnimatePresence (showPlus === true)
    └── PlusUpgradeModal  (z-[300]/z-[310])
        ├── Backdrop (blur(18px))
        ├── AnimatePresence (confirmed success animation)
        ├── Header (glow blob, billing toggle, price)
        ├── Body (feature grid, comparison table)
        ├── Mental model footer
        └── CTA footer
```

**Props flow:** All props flow DOWN from MetisExtension. No Context. No Zustand. Every panel receives `metrics`, `isPlusUser`, and callbacks.

---

## 4. PANEL GEOMETRY

```
Tab button:    fixed right-0, bottom: "5rem", minWidth: 44px
               borderRadius: "12px 0 0 12px"  (flat right edge)
               border: "1px solid rgba(255,255,255,0.1)", borderRight: "none"

Mini panel:    fixed right-0 top-0 bottom-0, w-[288px], z-50
               background: PANEL_BG, borderLeft: "1px solid rgba(255,255,255,0.06)"

Full panel:    fixed right-5 top-5 bottom-5, w-[410px], z-50
               background: PANEL_BG, border: "1px solid rgba(255,255,255,0.07)"
               borderRadius on container: rounded-2xl (16px)
               backdrop: fixed inset-0 z-40, background "rgba(0,0,0,0.2)", blur(3px)

Full report:   fixed inset-0 z-[100], centered, max-w-2xl (672px), maxHeight: "92vh"
               background: DARK_BG, borderRadius: 22, border: "1px solid rgba(255,255,255,0.08)"
               boxShadow: "0 40px 100px rgba(0,0,0,0.6)"
               backdrop: fixed inset-0 z-[90], background "rgba(0,0,0,0.72)", blur(16px)

Upgrade modal: fixed inset-0 z-[310], centered, max-w-xl (576px), maxHeight: "90vh"
               background: "#0d1825", borderRadius: 24, border: "1px solid rgba(255,255,255,0.09)"
               boxShadow: "0 48px 120px rgba(0,0,0,0.7)"
               backdrop: fixed inset-0 z-[300], background "rgba(0,0,0,0.78)", blur(18px)

Profile dropdown: absolute right-0 top-full mt-2, w-52, z-[200]
               background: "#0d1825", rounded-2xl, border: "1px solid rgba(255,255,255,0.1)"
               boxShadow: "0 20px 56px rgba(0,0,0,0.55)"
```

---

## 5. ANIMATION SPECS — EXACT VALUES

All enter/exit uses `AnimatePresence`. All springs use the exact values below. Do not approximate.

### Panel entry/exit
```tsx
// Tab button
initial={{ x: 80, opacity: 0 }}
animate={{ x: 0, opacity: 1 }}
exit={{ x: 80, opacity: 0 }}
transition={{ type: "spring", stiffness: 380, damping: 28 }}

// Mini panel
initial={{ x: 310, opacity: 0 }}
animate={{ x: 0, opacity: 1 }}
exit={{ x: 310, opacity: 0 }}
transition={{ type: "spring", stiffness: 340, damping: 30 }}

// Full panel
initial={{ x: 50, opacity: 0, scale: 0.97 }}
animate={{ x: 0, opacity: 1, scale: 1 }}
exit={{ x: 50, opacity: 0, scale: 0.97 }}
transition={{ type: "spring", stiffness: 340, damping: 30 }}

// Full Report modal
initial={{ scale: 0.9, y: 28, opacity: 0 }}
animate={{ scale: 1, y: 0, opacity: 1 }}
exit={{ scale: 0.9, y: 28, opacity: 0 }}
transition={{ type: "spring", stiffness: 360, damping: 28 }}

// Upgrade modal
initial={{ scale: 0.88, y: 32, opacity: 0 }}
animate={{ scale: 1, y: 0, opacity: 1 }}
exit={{ scale: 0.88, y: 32, opacity: 0 }}
transition={{ type: "spring", stiffness: 380, damping: 30 }}

// Profile dropdown
initial={{ opacity: 0, y: -8, scale: 0.94 }}
animate={{ opacity: 1, y: 0, scale: 1 }}
exit={{ opacity: 0, y: -8, scale: 0.94 }}
transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
```

### Score circle (SVG, requestAnimationFrame)
```ts
// Duration: 750ms. Easing: 1 - Math.pow(1 - t, 3)  (cubic ease-out)
// Track stroke: riskColor ? "rgba(255,255,255,0.06)" : "rgba(255,255,255,0.18)"
// Progress stroke: riskColor ?? "white"
// strokeWidth: 5.5, strokeLinecap: "round"
// r = size / 2 - 8
// SVG circle transition: style={{ transition: "stroke-dashoffset 0.04s linear" }}
// Score text: fontFamily "Jua", fontSize size * 0.24, fill "white", textAnchor "middle", dominantBaseline "central"
// Start: transform={`rotate(-90 ${size/2} ${size/2})`}  (12 o'clock)
```

### useCountUp hook
```ts
// Counts from 0 to target over durationMs. Resets to 0 on every target change.
// Same cubic ease-out: 1 - Math.pow(1 - t, 3)
// sessionCost: durationMs = 950
// monthlyAt10k: durationMs = 1100
```

### RiskBadge
```tsx
// Re-mounts via key={metrics.riskLabel}
initial={{ opacity: 0, scale: 0.9 }}
animate={{ opacity: 1, scale: 1 }}
transition={{ duration: 0.3 }}

// Pulsing dot inside:
animate={{ opacity: [1, 0.35, 1] }}
transition={{ duration: 1.8, repeat: Infinity }}
```

### Tab button pulse ring (score ≥ 60)
```tsx
animate={{
  boxShadow: [
    `inset 0 0 0px 0px ${metrics.riskColor}00`,
    `inset 0 0 12px 2px ${metrics.riskColor}40`,
    `inset 0 0 0px 0px ${metrics.riskColor}00`,
  ],
}}
transition={{ duration: 2.2, repeat: Infinity, ease: "easeInOut" }}
```

### Tab button risk dot (score ≥ 70)
```tsx
animate={{ scale: [1, 1.5, 1], opacity: [1, 0.6, 1] }}
transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
```

### Tab button hover/tap
```tsx
whileHover={{ x: -3 }}
whileTap={{ scale: 0.95 }}
transition={{ type: "spring", stiffness: 400, damping: 22 }}
```

### IssueTooltip
```tsx
initial={{ opacity: 0, y: 4, scale: 0.97 }}
animate={{ opacity: 1, y: 0, scale: 1 }}
exit={{ opacity: 0, y: 4, scale: 0.97 }}
transition={{ duration: 0.15 }}
// Position: absolute bottom: "calc(100% + 6px)" left-0 right-0 z-50 pointer-events-none
```

### FullIssueRow smart warning (hover expand)
```tsx
initial={{ opacity: 0, height: 0 }}
animate={{ opacity: 1, height: "auto" }}
exit={{ opacity: 0, height: 0 }}
style={{ overflow: "hidden" }}
// No explicit transition — uses default
```

### ScoreChangedBadge
```tsx
key={adj}  // Re-mounts on every change
initial={{ opacity: 0, y: -6, scale: 0.85 }}
animate={{ opacity: 1, y: 0, scale: 1 }}
exit={{ opacity: 0, scale: 0.85 }}
transition={{ duration: 0.3 }}
```

### WhatJustHappened expand
```tsx
initial={{ opacity: 0, height: 0 }}
animate={{ opacity: 1, height: "auto" }}
exit={{ opacity: 0, height: 0 }}
transition={{ duration: 0.22 }}
style={{ overflow: "hidden" }}
// ChevronDown: animate={{ rotate: open ? 180 : 0 }} transition={{ duration: 0.2 }}
```

### RefinedOutput expand
```tsx
initial={{ opacity: 0, height: 0, y: 8 }}
animate={{ opacity: 1, height: "auto", y: 0 }}
exit={{ opacity: 0, height: 0, y: 8 }}
transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
style={{ overflow: "hidden" }}
```

### Cost/metric value change animation
```tsx
// Triggered by key={row.value} or key={metrics.breakdown.total}
initial={{ opacity: 0, y: -4 }}
animate={{ opacity: 1, y: 0 }}
transition={{ duration: 0.35 }}
// For larger values: initial={{ opacity: 0, x: 8 }}
```

### LoadingScreen spinner
```tsx
animate={{ rotate: 360 }}
transition={{ duration: 1.2, repeat: Infinity, ease: "linear" }}
```

### Detection step reveal (LoadingScreen)
```tsx
initial={{ opacity: 0, x: -8 }}
animate={{ opacity: 1, x: 0 }}
transition={{ duration: 0.25, ease: "easeOut" }}
// Dot spring: { type: "spring", stiffness: 500, damping: 20 }
```

### StackChips stagger
```tsx
initial={{ opacity: 0, scale: 0.85 }}
animate={{ opacity: 1, scale: 1 }}
transition={{ delay: delay + i * 0.04 }}
```

### Mini issue rows stagger
```tsx
initial={{ opacity: 0, x: 6 }}
animate={{ opacity: 1, x: 0 }}
transition={{ delay: 0.05 * i }}
```

### Full issue rows stagger
```tsx
initial={{ opacity: 0, x: 8 }}
animate={{ opacity: 1, x: 0 }}
transition={{ delay: 0.04 * i }}
```

### Session cost live dot
```tsx
animate={{ opacity: [1, 0.4, 1] }}
transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
style={{ background: "#6366f1" }}  // indigo-500
```

### Button interactions
```tsx
// Primary CTA (Full Report button, Upgrade button)
whileHover={{ scale: 1.02 }}
whileTap={{ scale: 0.97 }}

// Small buttons / pills (PillGroup options)
whileHover={{ scale: 1.04 }}
whileTap={{ scale: 0.96 }}  // Note: 0.96, not 0.97

// Copy/icon buttons (CopyReportButton)
whileHover={{ scale: 1.04 }}
whileTap={{ scale: 0.93 }}

// Avatar button (ProfileButton)
whileHover={{ scale: 1.08 }}
whileTap={{ scale: 0.93 }}

// Export PDF header button
whileHover={{ scale: 1.06 }}
whileTap={{ scale: 0.93 }}
```

### CopyReportButton icon swap
```tsx
// AnimatePresence mode="wait" wraps both icons
// Copy idle: key="copy", CheckCheck copied: key="check"
initial={{ scale: 0 }}
animate={{ scale: 1 }}
exit={{ scale: 0 }}
// Reverts after setTimeout 2000ms
```

### Billing toggle (Upgrade modal)
```tsx
// layoutId="billing-pill" on the sliding active indicator div
transition={{ type: "spring", stiffness: 500, damping: 35 }}
```

### Plus upgrade success animation (5 steps)
```tsx
// 1. Background fade in
initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}

// 2. Crown circle spring
initial={{ scale: 0, rotate: -20 }}
animate={{ scale: 1, rotate: 0 }}
transition={{ type: "spring", stiffness: 420, damping: 22, delay: 0.1 }}

// 3. Sparkle orbit dots (5 dots at 0°,72°,144°,216°,288°)
animate={{ scale: [0, 1, 0], x: `calc(-50% + ${Math.cos(deg*Math.PI/180)*42}px)`, y: `calc(-50% + ${Math.sin(deg*Math.PI/180)*42}px)` }}
transition={{ delay: 0.25 + i * 0.06, duration: 0.7 }}

// 4. Text fade up
initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}

// 5. Progress bar fill
initial={{ width: "0%" }} animate={{ width: "100%" }}
transition={{ duration: 1.6, delay: 0.4, ease: "easeInOut" }}

// After 1800ms → onConfirm()
```

### Plus badge spring (appears after upgrade in headers)
```tsx
initial={{ scale: 0, opacity: 0 }}
animate={{ scale: 1, opacity: 1 }}
transition={{ type: "spring", stiffness: 480, damping: 22 }}
```

### Panel loading → content transition
```tsx
// AnimatePresence mode="wait"
// key="loading" for LoadingScreen, key="content" for real content
// Content enter: initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}
// Full panel content: initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }}
```

---

## 6. COMPONENT SPECS — EXACT IMPLEMENTATION

### 6.1 ScoreCircle
```tsx
// Props: score: number, size?: number = 100, riskColor?: string
// SVG ring using requestAnimationFrame (cubic ease-out, 750ms)
// r = size / 2 - 8
// circ = 2 * Math.PI * r
// offset = circ - (displayed / 100) * circ
// Track: stroke = riskColor ? "rgba(255,255,255,0.06)" : "rgba(255,255,255,0.18)"
// Ring: stroke = riskColor ?? "white", strokeWidth 5.5, strokeLinecap "round"
// transform={`rotate(-90 ${size/2} ${size/2})`}
// SVG transition: "stroke-dashoffset 0.04s linear"
// Text: fontSize={size * 0.24}, fontFamily "Jua, sans-serif", fill "white"
//       textAnchor "middle", dominantBaseline "central"
```

### 6.2 LoadingScreen
```tsx
// Background: transparent (inherits PANEL_BG from parent)
// className: "flex flex-col justify-center h-full px-5 py-6 gap-2"
// Initial opacity 0 → 1

// Header row: Loader2 (size 14, text-white/40) + "Analyzing page…" (Inter 11, rgba(255,255,255,0.35))
// Loader2 animates: rotate 360, duration 1.2, repeat Infinity, ease "linear"

// Detection steps: DETECTION_STEPS from data file
// Each step delayed by step.delay ms via setTimeout
// Visible steps revealed progressively
// Step row: flex items-center gap-2
//   dot: w-1.5 h-1.5 rounded-full, background step.dot (if any), spring scale
//   text: Inter 11, color: step.color
```

### 6.3 SectionLabel
```tsx
// Props: children: string, icon?: LucideIcon
// Layout: flex items-center gap-1.5 mb-3
// Icon: size={11}, className="text-white/30"
// Text: className="text-white/30 text-xs uppercase tracking-widest font-semibold"
//       style={{ fontFamily: "Inter, sans-serif", letterSpacing: "0.1em" }}
```

### 6.4 RiskBadge
```tsx
// Props: metrics: MetisMetrics, small?: boolean = false
// motion.div with key={metrics.riskLabel} for re-mount animation
// layout prop on motion.div
// className: "inline-flex items-center gap-1.5 rounded-full"
// style: { background: metrics.riskBg, padding: small ? "3px 10px" : "4px 12px" }
// Dot: w: small?6:7, h: small?6:7, rounded-full, background: metrics.riskColor
//      animate={{ opacity: [1,0.35,1] }}, transition={{ duration:1.8, repeat:Infinity }}
// Text: fontSize: small?10:11, fontFamily "Inter", fontWeight 600, color: metrics.riskColor
```

### 6.5 ScoreChangedBadge
```tsx
// Props: adj: number
// Returns null if adj === 0
// up = adj > 0
// className: "inline-flex items-center gap-1 rounded-full px-2 py-0.5 font-semibold"
// background: up ? "rgba(239,68,68,0.2)" : "rgba(34,197,94,0.2)"
// color: up ? "#fca5a5" : "#6ee7b7"
// fontSize: 10
// Content: {up ? "↑" : "↓"} {Math.abs(adj)} pts
```

### 6.6 IssueTooltip
```tsx
// Props: issue: IssueDefinition, visible: boolean
// Position: absolute left-0 right-0 z-50 pointer-events-none
//           bottom: "calc(100% + 6px)"
// Card: rounded-xl px-3 py-2.5 shadow-2xl
//   background: "#0c1623" (DARK_BG)
//   border: `1px solid ${issue.color}40`
//   boxShadow: `0 8px 32px rgba(0,0,0,0.5), 0 0 0 1px ${issue.color}20`
// Body text: text-white/70 leading-relaxed, Inter 11
// Trend row: TrendingDown size 9 (color issue.color) + span Inter 9 color issue.color
//   "~${issue.baseImpact}/mo impact · hover for details"
// Arrow: absolute left-4 bottom:-5 w-2.5 h-2.5 rotate-45
//   background DARK_BG, borderBottom+borderRight `1px solid ${issue.color}40`
```

### 6.7 MiniIssueRow
```tsx
// Props: issue, delay=0, onDark=false
// Wrapper: relative flex items-center gap-2 py-1.5 cursor-default
//   borderBottom: `1px solid ${onDark?"rgba(255,255,255,0.06)":"rgba(255,255,255,0.1)"}`
// IssueTooltip sits inside (visible on hover)
// Dot: w-1.5 h-1.5 rounded-full, background issue.color
// Title: flex-1 text-white text-xs, fontFamily Inter
// Badge: rounded-full px-1.5 py-0.5, background issue.color+"22", color issue.color
//        Inter, fontSize 9, text: issue.severity
```

### 6.8 FullIssueRow
```tsx
// Props: issue, delay=0, onDark=false
// Hover state tracked via useState
// bg: onDark ? "rgba(255,255,255,0.04)" : "rgba(255,255,255,0.1)"
// Wrapper: rounded-xl p-3 flex items-start gap-3 cursor-default
//   background: hovered ? (onDark?"rgba(255,255,255,0.07)":"rgba(255,255,255,0.14)") : bg
//   transition: "background 0.15s"
// Icon: issue.icon size 13, color issue.color, shrink-0 mt-0.5
// Title: text-white font-semibold Inter 12
// Severity badge: rounded-full px-1.5 py-0.5, bg issue.color+"25", color issue.color, Inter 9
// Description: text-white/45 mt-0.5 leading-relaxed, Inter 11
// Smart warning (hovered): AnimatePresence → motion.p
//   italic, Inter 10, color: issue.color+"cc"
//   "⚠ This may scale poorly — ~${issue.baseImpact * 10}/mo at 10× traffic"
```

### 6.9 StackChips
```tsx
// Props: compact=false, delay=0, onDark=false
// compact: shows first 4 + overflow chip "+N more"
// chipBg: onDark?"rgba(255,255,255,0.07)":"rgba(255,255,255,0.12)"
// Each chip: flex items-center gap-1.5 rounded-full px-2.5 py-1, background chipBg
//   Dot: w-1.5 h-1.5 rounded-full, background item.color
//   Label: text-white/65, Inter 11
// Overflow: rounded-full px-2.5 py-1
//   bg: onDark?"rgba(255,255,255,0.04)":"rgba(255,255,255,0.08)"
//   text: text-white/30 Inter 11, "+{N} more"
```

### 6.10 CostBreakdownRows
```tsx
// Props: breakdown: CostBreakdown, delay=0, onDark=false
// 3 rows: [{label:"Bandwidth",value:breakdown.bandwidth,icon:"↕"},
//          {label:"Requests / Compute",value:breakdown.requests,icon:"⚡"},
//          {label:"AI API Usage",value:breakdown.ai,icon:"🤖"}]
// rowBg: onDark?"rgba(255,255,255,0.04)":"rgba(255,255,255,0.08)"
// Each row: flex items-center justify-between rounded-xl px-4 py-2.5
//   Left: emoji icon + label (text-white/65, Inter 12)
//   Right: motion.span key={row.value}, Jua 12, "~${row.value}/mo"
//          animate: opacity 0→1, y -4→0, duration 0.35
// Total row: flex items-center justify-between px-4 pt-1 (no background)
//   Left: "Total estimated waste", text-white/30, Inter 11
//   Right: motion.span key={total}, Jua 14, scale 0.9→1, "~${total}/mo"
```

### 6.11 ScaleSimulation (Plus only)
```tsx
// Props: metrics: MetisMetrics
// costPerUser = metrics.breakdown.total / 1000
// aiPerRequest = (metrics.breakdown.ai / 1000 / 120).toFixed(4)
// 5 scenarios: [{users:"1k",mult:1},{users:"5k",mult:5},{users:"10k",mult:10},{users:"50k",mult:50},{users:"100k",mult:100}]

// AI cost row (top):
//   rounded-xl px-4 py-3 mb-3
//   background "rgba(16,163,127,0.08)", border "1px solid rgba(16,163,127,0.15)"
//   🤖 icon + 2-line label + "~$aiPerRequest" (Jua 13)

// Scenario table:
//   rounded-xl overflow-hidden, border "1px solid rgba(255,255,255,0.07)"
//   Header: grid-cols-3 px-4 py-2, bg "rgba(255,255,255,0.04)"
//   Rows: grid-cols-3 px-4 py-2.5
//     isBase (i===0): bg "rgba(220,94,94,0.06)"
//     Alt rows: transparent / "rgba(255,255,255,0.015)"
//     Users col: Users icon size 10 text-white/25 + "{s.users} users"
//       color: isBase ? METIS_RED : "rgba(255,255,255,0.65)"
//     "now" pill: rounded-full px-1.5 py-0.5, bg "rgba(220,94,94,0.18)", color METIS_RED, Inter 8
//     Scenario col: text-white/30, Inter 10
//     Cost col: motion.span key={monthly}, Jua 12, text-right font-bold
//       color: mult>=50?"#ef4444":mult>=10?"#f97316":"rgba(255,255,255,0.75)"
//       format: monthly>=1000 ? "$Xk" : "$X"

// Footer: text-white/18, Inter 9, text-right
```

### 6.12 SelectField
```tsx
// Props: label, placeholder, options[], value, onChange, optional=false
// Wrapper: space-y-1.5
// Label row: flex items-center gap-1.5
//   Label text: text-white/55 font-semibold, Inter 11
//   "(optional)" text: text-white/25, Inter 11
// Select wrapper: relative
// Select: w-full appearance-none rounded-xl px-3 py-2.5 pr-8
//   background "rgba(255,255,255,0.06)"
//   color: value ? "rgba(255,255,255,0.9)" : "rgba(255,255,255,0.3)"
//   border "1px solid rgba(255,255,255,0.1)", outline none, Inter 12
//   placeholder option: background "#0c1623", color "#555", disabled
//   real options: background "#162030", color white
// ChevronDown: absolute right-3 top-1/2 -translate-y-1/2, size 11, text-white/30, pointer-events-none
```

### 6.13 PillGroup
```tsx
// Props: label, options[], value, onChange, important=false
// Wrapper: space-y-2
// Header row: flex items-center gap-2
//   Label: text-white/55 font-semibold, Inter 11
//   "Most Important" badge (if important=true):
//     rounded-full px-2 py-0.5 font-semibold
//     background "rgba(249,115,22,0.18)", color "#f97316", Inter 9
// Pills: flex gap-1.5 flex-wrap
// Each pill: rounded-xl px-3 py-1.5 font-semibold
//   active: bg "rgba(249,115,22,0.25)", border "rgba(249,115,22,0.5)", color "#f97316"
//   inactive: bg "rgba(255,255,255,0.06)", border "rgba(255,255,255,0.1)", color "rgba(255,255,255,0.55)"
//   Inter 11, whileHover scale 1.04, whileTap scale 0.96
```

### 6.14 ImproveAccuracyForm
```tsx
// Props: inputs: AccuracyInputs, onChange: (next) => void
// Container: rounded-2xl p-5 space-y-5
//   background "rgba(255,255,255,0.03)", border "1px solid rgba(255,255,255,0.07)"

// Header: flex items-center gap-2
//   Target icon size 11, text-white/30
//   "Improve Accuracy" span: text-white/30 uppercase tracking-widest font-semibold, Inter 11, letterSpacing "0.1em"
//   "· updates score in real-time": text-white/20, Inter 11

// Fields order:
// 1. PillGroup "Pages per Session" options=["1–2","3–5","5–10","10+"] important={true}
// 2. PillGroup "App Type" options=["Static Site","SaaS Dashboard","Content-Heavy","AI-Heavy"]
// 3. SelectField "Hosting Provider" options=[AWS,Vercel,Google Cloud,Azure,DigitalOcean,Netlify,Render,Railway,Other]
// 4. SelectField "Plan Tier" options=[Free,Hobby,Pro,Business,Enterprise]
// 5. SelectField "Site Size" options=["<10 pages","10–50","50–200","200+"] optional={true}
// 6. Traffic slider:
//    Label row: flex items-center justify-between
//      "Monthly Traffic": text-white/55 font-semibold Inter 11
//      Value: motion.span key={inputs.traffic}, Jua 12, animate: y -4→0
//             "{fmtTraffic(inputs.traffic)} users/mo"
//    input[type=range] min=1 max=10000 step=10
//      h-1.5 rounded-full appearance-none cursor-pointer
//      background: linear-gradient(to right, rgba(255,255,255,0.6) ${pct}%, rgba(255,255,255,0.1) ${pct}%)
//      where pct = (inputs.traffic / 10000) * 100
//    Labels: "1 user" ... "10k users", text-white/20, Inter 10, flex justify-between
```

### 6.15 RefinedOutput
```tsx
// Props: metrics, inputs, visible: boolean
// Container: AnimatePresence → motion.div (height 0→auto, opacity, y)
// Card: rounded-2xl p-5 space-y-4
//   background "rgba(220,94,94,0.08)", border "1px solid rgba(220,94,94,0.2)"
// Header row: flex items-center justify-between
//   Left: RefreshCw size 11 text-white/35 + "Refined Estimate" label (Inter 10, text-white/35, letterSpacing "0.1em")
//   Right: <ScoreChangedBadge adj={metrics.scoreAdj} />
// Context note (if any filled inputs):
//   "Calibrated for " + contextParts.join(" · ")
//   text-white/35 Inter 11, contextParts in text-white/55
// Cost range row: flex items-center justify-between rounded-xl px-4 py-3
//   bg "rgba(255,255,255,0.07)"
//   "Estimated cost risk" text-white/60 Inter 12
//   motion.span key={total}, Jua 16, x 8→0, "${min}–${max}/mo"
// CostBreakdownRows breakdown={metrics.breakdown} onDark
```

### 6.16 SessionCostBlock
```tsx
// Props: metrics, compact=false
// Wrapper: rounded-xl overflow-hidden, border "1px solid rgba(255,255,255,0.08)"

// Provenance chip:
//   flex items-center gap-1.5 px-3 py-1.5
//   bg "rgba(255,255,255,0.04)", borderBottom "1px solid rgba(255,255,255,0.06)"
//   Live dot: w-1.5 h-1.5 rounded-full bg "#6366f1", opacity pulse [1,0.4,1] duration 2
//   Text: "Live · Sampled {pages} pages · app.example.com", text-white/35, Inter 10

// Session cost row:
//   px-3 py-2.5 flex items-center justify-between, bg "rgba(255,255,255,0.03)"
//   Left: "Current session cost ({pages} pages)" text-white/50 Inter compact?10:11
//         "Counting as page loads · estimated" text-white/25 Inter 10 (hidden in compact)
//   Right: fmtCost(animatedSessionCost), Jua compact?13:15, tabular-nums

// Scale row:
//   px-3 py-2 flex items-center gap-2
//   bg "rgba(99,102,241,0.07)", borderTop "1px solid rgba(99,102,241,0.15)"
//   Zap size 10 text-indigo-400 shrink-0
//   "At 10k users →" text-white/40 Inter 10
//   "~{fmtMonthly(animatedMonthly)}/month" Jua 11 color "#a5b4fc" tabular-nums
```

### 6.17 PremiumSection
```tsx
// Props: compact=false, onUpgrade?: () => void
// Outer: relative rounded-2xl overflow-hidden
// Preview rows (blurred):
//   compact: 2 rows, non-compact: 4 rows
//   filter "blur(4px)", pointerEvents "none", userSelect "none"
//   bg "rgba(255,255,255,0.03)", space-y-2 p-4
//   Each row: rounded-xl px-4 py-3 flex items-center gap-3, bg "rgba(255,255,255,0.06)"
//     TrendingDown size 12 text-white/40 + text-white/60 Inter 12
// Overlay:
//   absolute inset-0 flex flex-col items-center justify-center gap-3
//   bg "rgba(12,22,35,0.7)", backdropFilter blur(3px)
//   Lock icon in rounded-full p-2.5 bg "rgba(255,255,255,0.1)"
//   "Unlock Full Metis Report" text-white font-semibold Inter 12
//   Buttons: flex (compact:flex-col, non-compact:flex-row) gap-2
//     Primary: rounded-full px-4 py-1.5 font-bold, bg METIS_RED, color white, Inter 11
//              Sparkles size 11, "Upgrade to Plus"
//     Secondary (non-compact): rounded-full px-4 py-1.5 font-bold
//              bg "rgba(255,255,255,0.12)", border "1px solid rgba(255,255,255,0.2)"
//              Wrench size 11, "Fix this for me"
```

### 6.18 ProfileButton
```tsx
// Props: onDark=false, onUpgrade, isPlusUser=false
// avatarBg: onDark?"rgba(255,255,255,0.1)":"rgba(255,255,255,0.2)"
// Avatar: w-7 h-7 rounded-full, background avatarBg, border "1.5px solid rgba(255,255,255,0.18)"
//   "JD" text-white font-bold Inter 10, whileHover scale 1.08, whileTap scale 0.93

// Dropdown (AnimatePresence, open state):
//   background "#0d1825", rounded-2xl, w-52, overflow-hidden
//   border "1px solid rgba(255,255,255,0.1)", boxShadow "0 20px 56px rgba(0,0,0,0.55)"
//
//   User row: px-4 py-3.5, borderBottom "1px solid rgba(255,255,255,0.07)"
//     Avatar: w-9 h-9 rounded-full, bg METIS_RED, "JD" Inter 13 font-bold
//     Name: "Jamie Dawson" text-white font-semibold Inter 12
//     Email: "jamie@acmecorp.io" text-white/40 Inter 10
//
//   Plan row: px-4 py-2.5 flex items-center justify-between
//     borderBottom "1px solid rgba(255,255,255,0.07)"
//     "Current plan" text-white/40 Inter 11
//     AnimatePresence mode="wait":
//       Plus: key="plus", rounded-full px-2.5 py-1, bg "rgba(220,94,94,0.18)", border "rgba(220,94,94,0.35)"
//             Crown size 9 METIS_RED + "Plus" Inter 10 METIS_RED font-bold
//       Free: key="free", rounded-full px-2.5 py-1, bg "rgba(255,255,255,0.08)"
//             Crown size 9 text-white/50 + "Free" text-white/60 Inter 10 font-semibold
//
//   Menu items: py-1.5
//     Free user: [{icon:Sparkles,label:"Upgrade to Plus",accent:true},{icon:Settings},{icon:LogOut}]
//     Plus user:  [{icon:Crown,label:"Metis+ Active",accent:true,disabled:true},{icon:Settings},{icon:LogOut}]
//     Each: w-full flex items-center gap-2.5 px-4 py-2.5, Inter 12 font-medium
//     Hover: bg "rgba(255,255,255,0.05)"
//     Icon: size 12, color: accent?METIS_RED:"rgba(255,255,255,0.35)"
//     Text: color: accent?METIS_RED:"rgba(255,255,255,0.65)"
```

### 6.19 WhatJustHappened
```tsx
// Toggle button: w-full flex items-center justify-between px-3 py-2 rounded-xl
//   bg: open?"rgba(255,255,255,0.07)":"rgba(255,255,255,0.04)"
//   border "1px solid rgba(255,255,255,0.08)"
//   Left: Activity size 11 text-white/40 + "What just happened?" Inter 11 "rgba(255,255,255,0.55)"
//   Right: ChevronDown size 11 text-white/30, animate rotate 0→180

// Events data (hardcoded):
//   { icon: Activity,  color: "#ef4444", label: "API requests on load",  value: "12 calls"       }
//   { icon: Cpu,       color: "#f97316", label: "AI completions fired",  value: "3 calls"        }
//   { icon: FileText,  color: "#eab308", label: "Heavy assets loaded",   value: "3 files › 2MB"  }
//   { icon: Clock,     color: "#6366f1", label: "Time to interactive",   value: "3.4s"           }

// Expanded content: rounded-xl overflow-hidden, border "rgba(255,255,255,0.07)"
//   Header: px-3 py-1.5, bg "rgba(255,255,255,0.03)", borderBottom "rgba(255,255,255,0.06)"
//     "LAST 10 SECONDS · app.example.com" Inter 9 text-white/30 letterSpacing "0.08em"
//   Event rows: flex items-center justify-between px-3 py-2
//     borderBottom (not last): "rgba(255,255,255,0.04)"
//     Left: ev.icon size 10 color ev.color + label Inter 10 "rgba(255,255,255,0.5)"
//     Right: ev.value, Jua 10, color ev.color
//     Stagger: delay: i * 0.06
```

### 6.20 CopyReportButton
```tsx
// px-3 py-2.5 rounded-xl flex items-center justify-center gap-1.5
// bg "rgba(255,255,255,0.06)", border "1px solid rgba(255,255,255,0.1)"
// color: copied?"#4ade80":"rgba(255,255,255,0.5)"
// AnimatePresence mode="wait":
//   Copy icon size 13, CheckCheck icon size 13
//   Both: initial scale 0, animate scale 1, exit scale 0

// Toast on copy: toast.success("Report copied!", {
//   description: "Paste it in Slack, Notion, or a client chat.",
//   duration: 2500
// })

// Clipboard text format:
// "Metis Cost Report — app.example.com
// Risk Score: {score}/100 ({riskLabel})
// Estimated waste: ~${min}–${max}/month
// Session cost: {fmtCost(sessionCost)} · At 10k users: ~{fmtMonthly(monthlyAt10k)}/month
// Top issues: {issue1}, {issue2}, {issue3}
// Quick insight: {quickInsight}
// — Scanned by Metis (metis.ward.studio)"
```

---

## 7. PANEL CONTENT STRUCTURE

### 7.1 MiniPanelContent (288px, PANEL_BG)

```
Header (px-4 pt-4 pb-3, borderBottom rgba(255,255,255,0.08)):
  Left: [w-6 h-6 rounded-md METIS_RED M-logo (Jua 14)] + "Metis" (Jua 14 bold) + [Plus badge if isPlusUser]
  Right: ProfileButton + Maximize2 (size 12) + X (size 12)

Body (AnimatePresence mode="wait"):
  Loading: LoadingScreen (1100ms)
  Content (px-4 py-4 space-y-5, scrollbarWidth:"none"):
    1. Score section (flex flex-col items-center gap-2 pt-1):
       ScoreCircle size=88 riskColor
       "Cost Risk: {score}" text-white/40 Inter 11 + bold score
       RiskBadge small

    2. Quick Insight (rounded-xl px-3 py-2.5, bg rgba(255,255,255,0.05), border rgba(255,255,255,0.07)):
       text-white/60 leading-snug Inter 11

    3. SessionCostBlock compact={true}

    4. Issues section:
       SectionLabel: isPlusUser ? "All 5 Issues · Metis+" : "Top Issues"
       Free: SORTED_ISSUES.slice(0,3) → MiniIssueRow each
       Plus: all 5 issues, each MiniIssueRow + fix hint block below
         Fix hint: ml-3.5 mb-2 px-2.5 py-1.5 rounded-lg
           bg "rgba(255,255,255,0.04)", borderLeft `2px solid ${issue.color}40`
           "Fix →" in issue.color + issue.fix.slice(0,80)+"…" (text-white/50 Inter 10)
           Savings badge: rounded-full px-1.5 py-0.5 bg "rgba(34,197,94,0.15)"
             color "#4ade80" Inter 9 bold "Save ~${issue.saving}/mo"

    5. Stack section:
       SectionLabel: "Detected Stack"
       StackChips compact delay=0.1
       Detection badges (flex gap-1.5 flex-wrap mt-2):
         AI: bg "rgba(16,163,127,0.15)", border "rgba(16,163,127,0.3)", "🤖" + "AI usage detected" color "#10a37f"
         Vercel: bg "rgba(99,102,241,0.12)", border "rgba(99,102,241,0.25)", "⚡" + "Vercel: cost driver" color "#a5b4fc"

Footer (px-4 pb-4 pt-3, borderTop rgba(255,255,255,0.08)):
  WhatJustHappened
  flex gap-2:
    "Full Report" button: flex-1 py-2.5 rounded-xl font-bold METIS_RED
      FileText size 12 + "Full Report" + ChevronRight size 12
    CopyReportButton
```

### 7.2 FullPanelContent (410px, PANEL_BG, rounded-2xl)

```
Header (px-5 pt-5 pb-4, borderBottom rgba(255,255,255,0.08)):
  Left: [w-8 h-8 rounded-lg METIS_RED M-logo (Jua 18)] + title group
    Title group: "Metis Scan" (Jua 14 bold) + [Plus badge] / "app.example.com · {time}" (Inter 11 text-white/35)
  Right: ProfileButton onDark + Minimize2 size 12 + X size 12

Body (AnimatePresence mode="wait"):
  Loading: LoadingScreen (1100ms)
  Content (flex-1 overflow-y-auto, scrollbarWidth:thin):
    Score section (px-5 py-5, borderBottom):
      flex items-center gap-4:
        ScoreCircle size=92 riskColor
        Right column:
          flex items-center gap-2 flex-wrap mb-1.5:
            score number: Jua 28 font-bold
            RiskBadge key={riskLabel} small (AnimatePresence mode="wait")
            ScoreChangedBadge (if adj !== 0)
          "Cost Risk Score" text-white/35 Inter 11
          "You may be wasting ~${min}–${max}/month": text-white/50 Inter 11
          quickInsight: text-white/35 Inter 11
      SessionCostBlock mt-4

    Problems section (px-5 py-5 space-y-2, borderBottom):
      SectionLabel icon={AlertCircle}: "5 Issues · By Severity"
      SORTED_ISSUES.map → FullIssueRow delay={0.04*i} onDark

    Known Stack (px-5 py-5, borderBottom):
      SectionLabel icon={Shield}: "Detected Stack"
      StackChips onDark delay=0.15
      "Auto-detected via network & DOM analysis" text-white/20 Inter 10 mt-3

    Premium/Plus section (AnimatePresence mode="wait"):
      Free key="locked": PremiumSection compact onUpgrade
      Plus key="plus-unlocked": Fix Recommendations (simplified card list)
        Header: Crown size 11 METIS_RED + "Fix Recommendations · Plus" Inter 10 METIS_RED
        Cards (space-y-2.5): each rounded-xl p-3
          bg "rgba(255,255,255,0.04)"
          border: i===0 ? issue.color+"44" : issue.color+"22"
          Priority: i===0 Trophy size 9 gold, else "#i+1" text-white/25 Inter 9
          Title: text-white font-semibold Inter 11
          "Fix First" badge (i===0): bg "rgba(255,215,0,0.15)", color "#ffd700", Inter 8
          "Save ~${saving}/mo" badge: bg "rgba(34,197,94,0.15)", color "#4ade80", Inter 9
          rootCause: "Why: " text-white/30 + body text-white/45 Inter 10 leading-1.5
          fix: issue.color "Fix → " + body text-white/60 Inter 10 leading-1.5

Footer (px-5 pb-5 pt-3, borderTop rgba(255,255,255,0.08)):
  Detection badges (flex items-center gap-1.5 flex-wrap mb-1):
    AI: bg "rgba(16,163,127,0.12)", border "rgba(16,163,127,0.25)", "🤖" + "AI detected · OpenAI" color "#10a37f"
    API: bg "rgba(249,115,22,0.12)", border "rgba(249,115,22,0.25)", "⚡" + "12 API calls on load" color "#f97316"
  flex gap-2:
    "Full Report" button (flex-1 py-2.5 rounded-xl METIS_RED bold Inter 12)
    CopyReportButton
```

### 7.3 FullReportModal (7 sections, max-w-2xl)

```
Modal header (px-6 py-5, borderBottom rgba(255,255,255,0.07)):
  Left: [w-8 h-8 rounded-lg METIS_RED M (Jua 16)] + "Metis Full Report" (Jua 14) / "app.example.com · {date}" (Inter 11 text-white/30)
  Right:
    [If Plus: Plus badge + Export PDF button (Download size 10, bg rgba(96,165,250,0.12), border rgba(96,165,250,0.25), color "#60a5fa")]
    ProfileButton onDark
    X size 15 text-white/35

Scrollable body (AnimatePresence: loading 900ms → content):
  § 1 Overview (px-6 py-6, borderBottom rgba(255,255,255,0.06)):
    flex items-start gap-6:
      ScoreCircle size=108 riskColor
      Right:
        score number: Jua 42 + RiskBadge (AnimatePresence mode="wait") + ScoreChangedBadge
        "Cost Risk Score" text-white/40 Inter 12
        Cost range box: rounded-xl px-4 py-3 inline-block, bg "rgba(255,255,255,0.05)"
          "${min}–${max}/month estimated waste" Jua 15
          "Driven by bandwidth, requests, and API usage" text-white/40 Inter 11
        SessionCostBlock mb-3
        Severity pills:
          per sev in [critical,moderate,low]:
            rounded-lg px-2.5 py-1 flex items-center gap-1.5
            bg: color+"18"
            dot w-1.5 h-1.5 rounded-full in color
            "{count} {sev}" Inter 11 font-semibold capitalize, color

  § 2 Cost Breakdown (px-6 py-6, borderBottom):
    SectionLabel icon={Zap}: "Cost Breakdown"
    "Where your estimated waste is coming from" text-white/28 Inter 11 mb-4
    CostBreakdownRows breakdown={metrics.breakdown} onDark delay=0.05

  § 2b Scale Simulation (Plus only, px-6 py-6, borderBottom):
    SectionLabel icon={Target}: "Scale Simulation · Plus"
    "If traffic grows, here's what this cost profile becomes" text-white/28 mb-4
    ScaleSimulation metrics={metrics}

  § 3 Problems (px-6 py-6, borderBottom):
    SectionLabel icon={AlertCircle}: "Problems · Sorted by Severity"
    space-y-2: SORTED_ISSUES.map → FullIssueRow delay={0.04*i} onDark

  § 4 Known Stack (px-6 py-6, borderBottom):
    SectionLabel icon={Shield}: "Known Stack"
    space-y-3: MOCK_DETAILED_STACK.map → flex items-start gap-3
      Left: category label, text-white/25 w-28 Inter 11
      Right: flex flex-wrap gap-1.5 → each item chip:
        rounded-full px-2.5 py-1, bg "rgba(255,255,255,0.07)", text-white/65 Inter 11
        If matching MOCK_STACK_ITEMS → brand colour dot inline
    "Auto-detected via network & DOM analysis" text-white/20 Inter 10 mt-4

  § 5 Improve Accuracy (px-6 py-6, borderBottom):
    ImproveAccuracyForm inputs onChange

  § 6 Refined Output (px-6 py-6, borderBottom — only if hasInputs):
    RefinedOutput metrics inputs visible={hasInputs}

  § 7 Fix Recommendations / Lock (AnimatePresence mode="wait"):
    Plus key="plus-fixes" (px-6 py-6, borderTop):
      Header row: Crown size 11 METIS_RED + "Fix Recommendations · Metis+" Inter 10 METIS_RED
        Total savings badge (ml-auto): bg "rgba(34,197,94,0.15)", color "#4ade80"
          "Total savings: ~${total}/mo" Inter 10 font-bold
      space-y-4: SORTED_ISSUES.map → Fix Recommendation card (rounded-2xl overflow-hidden)
        See Section 9 below for card anatomy.

    Free key="locked" (px-6 py-6):
      Lock size 11 + "Unlock Full Metis Report" Inter 10 text-white/30 uppercase
      PremiumSection onUpgrade

Modal footer (px-6 py-4, borderTop rgba(255,255,255,0.07)):
  Left: "ward.studio/metis" text-white/20 Inter 11
  Right: flex items-center gap-2
    Copy button: rounded-xl px-3 py-2, bg "rgba(255,255,255,0.05)", border "rgba(255,255,255,0.08)"
      Copy size 11, "Copy" Inter 11 font-semibold, color "rgba(255,255,255,0.5)"
    Export PDF button: rounded-xl px-5 py-2.5
      isPlusUser: bg "rgba(96,165,250,0.12)", border "rgba(96,165,250,0.25)", color "#60a5fa"
      Free: bg "rgba(255,255,255,0.07)", border "rgba(255,255,255,0.1)", color "rgba(255,255,255,0.65)"
      Download size 12, Inter 12 font-semibold
      text: isPlusUser ? "Export PDF" : "Export PDF (Plus)"
```

---

## 8. FIX RECOMMENDATION CARD ANATOMY (Full Report § 7)

Each issue card is a `rounded-2xl overflow-hidden` with two layers:

```
Card border: 1px solid ${i===0 ? issue.color+"55" : issue.color+"25"}
Card shadow (i===0 only): boxShadow: `0 0 20px ${issue.color}10`

Card header (flex items-center justify-between px-4 py-3):
  bg: issue.color + (i===0?"20":"12")
  Left group (flex items-center gap-2):
    Priority circle (w-5 h-5 rounded-full flex items-center justify-center):
      i===0: bg "rgba(255,215,0,0.2)", border "1px solid rgba(255,215,0,0.4)"
             Trophy size 9 color "#ffd700"
      else:  bg "rgba(255,255,255,0.08)", border "1px solid rgba(255,255,255,0.1)"
             "#{i+1}" Inter 8 font-bold color "rgba(255,255,255,0.4)"
    issue.icon size 12 color issue.color
    issue.title text-white font-semibold Inter 12
    severity badge: rounded-full px-1.5 py-0.5, bg issue.color+"25", color issue.color, Inter 9
    "Fix First" badge (i===0 only):
      flex items-center gap-1 rounded-full px-2 py-0.5 font-bold
      bg "rgba(255,215,0,0.15)", color "#ffd700", Inter 9
      Trophy size 8
  Right: "Save ~${issue.saving}/mo" badge
    rounded-full px-2.5 py-1 font-bold shrink-0
    bg "rgba(34,197,94,0.15)", color "#4ade80", Inter 10

Card body (px-4 py-3 space-y-2.5, bg "rgba(255,255,255,0.02)"):
  Root cause block:
    "ROOT CAUSE" label: text-white/30 Inter 10 letterSpacing "0.05em" mb-1
    Body: text-white/55 leading-relaxed Inter 11
  Fix block (rounded-xl px-3 py-2.5, bg "rgba(255,255,255,0.04)", borderLeft `3px solid ${issue.color}`):
    "FIX" label: Inter 10 color issue.color letterSpacing "0.05em" mb-1
    Body: text-white/70 leading-relaxed Inter 11
  Scale impact row (flex items-center gap-2):
    TrendingDown size 10 text-indigo-400 shrink-0
    issue.scaleImpact: text-white/35 italic Inter 10
```

---

## 9. PLUS UPGRADE MODAL ANATOMY

```
Header (px-6 pt-6 pb-5, borderBottom rgba(255,255,255,0.07)):
  Glow blob: absolute top-0 left-1/2 -translate-x-1/2, w-48 h-16 rounded-full
    bg "radial-gradient(ellipse, rgba(220,94,94,0.22) 0%, transparent 70%)", filter blur(20px)
  X button: absolute right-5 top-5, X size 14 text-white/35
  Centered column (flex flex-col items-center gap-2):
    Metis+ badge: rounded-full px-4 py-1.5
      bg "rgba(220,94,94,0.15)", border "rgba(220,94,94,0.3)"
      Crown size 12 METIS_RED + "Metis+" Jua 14 METIS_RED font-bold
    H2: "Stop guessing. Start fixing." Jua 22 text-white text-center
    Description: text-white/40 text-center max-w-xs Inter 12
    Billing toggle (flex, rounded-full p-1, bg "rgba(255,255,255,0.06)", border "rgba(255,255,255,0.08)"):
      Two buttons: "Monthly" / "Annual"
        Active: layoutId="billing-pill" sliding div, bg "rgba(255,255,255,0.12)", spring 500/35
        Active text: white font-semibold
        Inactive text: rgba(255,255,255,0.35)
        "Save 22%" badge on Annual: bg "rgba(34,197,94,0.2)", color "#4ade80", Inter 9 font-bold
    Price display (flex items-end gap-1.5 mt-1):
      Price: motion.span key={price} Jua 36, y -6→0 on change
      "/month{billing==='annual'?', billed annually':''}" text-white/35 mb-1.5 Inter 12

Body (px-6 py-5 space-y-5, overflow-y-auto scrollbarWidth none):
  Feature grid (grid grid-cols-2 gap-2.5):
    6 cards: rounded-2xl p-4 relative
      bg "rgba(255,255,255,0.04)", border "rgba(255,255,255,0.07)"
      Tag badge (if tag): absolute top-3 right-3 rounded-full px-2 py-0.5 font-bold
        "Coming Soon": bg "rgba(99,102,241,0.2)", color "#a5b4fc"
        "Most Popular": bg "rgba(34,197,94,0.2)", color "#4ade80"
        Inter 8 font-bold
      Icon wrapper: w-7 h-7 rounded-xl flex items-center justify-center mb-3, bg f.color+"1a"
        f.icon size 13 color f.color
      Title: text-white font-semibold Inter 12 mb-1
      Description: text-white/38 leading-relaxed Inter 11

  Comparison table (rounded-2xl overflow-hidden, border "rgba(255,255,255,0.07)"):
    Header row: grid-cols-3 px-4 py-2.5, bg "rgba(255,255,255,0.04)", borderBottom
      "Feature" / "Free" / [Crown size 9 METIS_RED + "Plus" METIS_RED Inter 10 font-bold]
    Data rows: grid-cols-3 px-4 py-2 items-center
      Alternating bg: transparent / "rgba(255,255,255,0.015)"
      borderBottom between rows: "rgba(255,255,255,0.04)"
      Feature: text-white/55 Inter 11
      Free: ✓ circle (bg "rgba(34,197,94,0.15)", "✓" color "#4ade80" fontSize 10) OR "—" text-white/15 fontSize 12
      Plus: always ✓ circle (bg "rgba(220,94,94,0.18)", "✓" color METIS_RED fontSize 10)

Mental model (px-6 py-4, borderTop rgba(255,255,255,0.06)):
  "THE METIS WAY" text-center text-white/20 Inter 10 letterSpacing "0.06em" mb-3
  flex items-stretch gap-2:
    Free column (flex-1 rounded-xl p-3, bg "rgba(255,255,255,0.03)", border "rgba(255,255,255,0.06)"):
      "FREE" label Inter 9 text-center text-white/30 letterSpacing "0.08em" mb-2
      Steps: ["🔍 Detect","📊 Estimate","👁 Reveal"]
        each: flex items-center gap-1.5 py-1
        ArrowRight size 8 text-white/15 between steps (i>0)
        Text: Inter 10, "rgba(255,255,255,0.45)"
    Plus column (flex-1 rounded-xl p-3, bg "rgba(220,94,94,0.06)", border "rgba(220,94,94,0.2)"):
      [Crown size 8 METIS_RED] + "PLUS" METIS_RED Inter 9 letterSpacing "0.08em" mb-2
      Steps: ["💡 Explain","🛠 Guide","⚡ Optimize"]
        ArrowRight size 8 color METIS_RED+"40" between steps
        Text: Inter 10, "rgba(255,255,255,0.7)"

CTA footer (px-6 pb-6 pt-4, borderTop rgba(255,255,255,0.07)):
  Primary: w-full py-3 rounded-2xl font-bold flex items-center justify-center gap-2
    bg METIS_RED, color white, Inter 13, boxShadow "0 8px 24px rgba(220,94,94,0.35)"
    Sparkles size 13, "Upgrade to Metis+ — ${price}/mo"
    Disabled when confirmed: opacity 0.6
  Secondary: w-full py-2.5 rounded-2xl font-semibold flex items-center justify-center gap-2
    bg "rgba(255,255,255,0.06)", border "rgba(255,255,255,0.08)", color "rgba(255,255,255,0.45)", Inter 12
    Wrench size 11, "Fix this for me (Agency)"
  Disclaimer: text-center text-white/20 Inter 10
    "Cancel anytime · No credit card needed for free tier"
```

---

## 10. SCORING ENGINE

**File:** `/src/app/lib/scoring.ts` — pure function, no React.

```ts
function computeMetrics(inputs: AccuracyInputs): MetisMetrics

BASE_SCORE = 72

// adj accumulates:
HOSTING_ADJ = { AWS:-5, Vercel:4, "Google Cloud":-4, Azure:-4, DigitalOcean:2, Netlify:6, Render:3, Railway:2, Other:0 }
PLAN_ADJ    = { Free:9, Hobby:4, Pro:0, Business:-4, Enterprise:-8 }
APP_ADJ     = { "Static Site":-10, "SaaS Dashboard":8, "Content-Heavy":3, "AI-Heavy":15, SaaS:5, "E-commerce":9, "Blog / Content":-6, Portfolio:-9, Marketplace:12, "Internal Tool":-3, Other:0 }
PAGES_ADJ   = { "1–2":-6, "3–5":0, "5–10":8, "10+":15 }
SITE_SIZE_ADJ = { "<10 pages":-5, "10–50":0, "50–200":3, "200+":7 }
PAGES_COUNT = { "1–2":1.5, "3–5":4, "5–10":7.5, "10+":12 }

// Traffic band:
t < 200  → adj -= 7
t < 800  → adj -= 3
t < 1500 → adj += 0 (baseline)
t < 4000 → adj += 5
t < 7000 → adj += 10
else     → adj += 16

score = clamp(1, 100, BASE_SCORE + adj)

// Cost breakdown:
trafficFactor = clamp(0.35, 3.0, inputs.traffic / 2000)
sf = score / BASE_SCORE  (BASE_SCORE = 72)
bandwidth = max(2, round(12 * trafficFactor * sf))
requests  = max(1, round(10 * sf))
ai        = max(1, round(8 * sf))
total     = bandwidth + requests + ai

// quickInsight:
score >= 80 → "Severe API overuse and memory pressure detected"
score >= 70 → "High request count and AI usage detected"
score >= 55 → "Moderate cost inefficiencies across 5 issues"
score >= 40 → "Minor optimizations available, low risk"
else        → "Site is well-optimized — low cost risk detected"

// Cost range:
costRangeMin = round(total * 0.75)
costRangeMax = round(total * 1.35)

// Session cost:
pagesCount  = PAGES_COUNT[inputs.pagesPerSession] ?? 4
costPerUser = total / max(1, inputs.traffic)
sessionCost = costPerUser * (pagesCount / 4)
monthlyAt10k = costPerUser * 10000

// Pages scanned:
score >= 70 → 5, score >= 50 → 4, else → 3
```

**Format utilities:**
```ts
fmtCost(n):   n<0.001 → "$X.X" (tenths of cent)
              n<0.01  → "$X.XXXX"
              n<0.1   → "$X.XXX"
              n<10    → "$X.XX"
              else    → "$X"
fmtMonthly(n): n>=10000→"$Xk", n>=1000→"$X.Xk", else→"$X"
fmtTraffic(v): v>=1000→"X.Xk", else→"X"
```

---

## 11. DETECTION FEED DATA

```ts
DETECTION_STEPS = [
  { delay: 0,    text: "Scanning network requests…",       color: "rgba(255,255,255,0.3)", dot: null      },
  { delay: 280,  text: "DOM analysis running…",            color: "rgba(255,255,255,0.3)", dot: null      },
  { delay: 520,  text: "AI usage detected ⚠",             color: "#f97316",               dot: "#f97316" },
  { delay: 700,  text: "Duplicate API calls found",        color: "#ef4444",               dot: "#ef4444" },
  { delay: 860,  text: "Memory leak pattern detected",     color: "#ef4444",               dot: "#ef4444" },
  { delay: 1010, text: "3 unoptimized images identified",  color: "#f97316",               dot: "#f97316" },
  { delay: 1160, text: "Missing cache headers found",      color: "#eab308",               dot: "#eab308" },
  { delay: 1320, text: "Calculating cost risk score…",     color: "rgba(255,255,255,0.3)", dot: null      },
]
DETECTION_TOTAL_DURATION_MS = 1100
```

---

## 12. MOCK DATA — ALL VALUES

### Stack items
```ts
MOCK_STACK_ITEMS = [
  { name: "React 18",         color: "#61dafb", category: "Framework"  },
  { name: "Next.js 14",       color: "#aaaaaa", category: "Framework"  },
  { name: "Vercel",           color: "#6366f1", category: "Hosting"    },
  { name: "OpenAI API",       color: "#10a37f", category: "AI"         },
  { name: "Stripe",           color: "#6772e5", category: "Payment"    },
  { name: "Google Analytics", color: "#f9a825", category: "Analytics"  },
  { name: "Cloudflare CDN",   color: "#f6821f", category: "CDN"        },
]

MOCK_DETAILED_STACK = [
  { label: "Framework",     items: ["React 18", "Next.js 14"]      },
  { label: "Hosting / CDN", items: ["Vercel", "Cloudflare CDN"]    },
  { label: "AI Providers",  items: ["OpenAI GPT-4"]                },
  { label: "Analytics",     items: ["Google Analytics 4"]           },
  { label: "Payment",       items: ["Stripe v3"]                    },
]
```

### Issues (sorted: critical → moderate → low)
```ts
[
  { severity:"critical", title:"Duplicate API Requests",   color:"#ef4444", icon:AlertCircle,  baseImpact:8,  saving:8  },
  { severity:"critical", title:"Memory Leak Pattern",      color:"#ef4444", icon:AlertCircle,  baseImpact:5,  saving:5  },
  { severity:"moderate", title:"Unoptimized Images",       color:"#f97316", icon:AlertTriangle,baseImpact:4,  saving:4  },
  { severity:"moderate", title:"AI API Call Frequency",    color:"#f97316", icon:AlertTriangle,baseImpact:11, saving:11 },
  { severity:"low",      title:"Missing Cache Headers",    color:"#eab308", icon:Info,         baseImpact:2,  saving:2  },
]
```

### Plus features grid
```ts
PLUS_FEATURES = [
  { icon: TrendingDown, color: "#22c55e", title: "Fix Recommendations",    tag: "Most Popular" },
  { icon: Zap,          color: "#f97316", title: "Savings Estimate",       tag: null           },
  { icon: RefreshCw,    color: "#6366f1", title: "Multi-Page Scan",        tag: "Coming Soon"  },
  { icon: Target,       color: "#f97316", title: "Scale Impact Preview",   tag: null           },
  { icon: Shield,       color: "#a78bfa", title: "Root Cause Analysis",    tag: null           },
  { icon: Download,     color: "#60a5fa", title: "Full PDF Export",        tag: null           },
]
```

### Default inputs
```ts
DEFAULT_INPUTS = {
  hosting: "",
  plan: "",
  traffic: 1000,
  appType: "",
  pagesPerSession: "3–5",
  siteSize: "",
}
```

---

## 13. ACCESSIBILITY & INTERACTION RULES

1. All `<button>` elements that open panels use `onClick`. Keyboard focus follows click path.
2. Profile dropdown closes on `mousedown` outside via `document.addEventListener`.
3. Tooltip (`IssueTooltip`) is `pointer-events-none` — pure visual overlay.
4. Blurred premium preview has `userSelect: "none"` and `pointerEvents: "none"`.
5. Loading screens use `AnimatePresence mode="wait"` to prevent layout shift.
6. All modals use `e.stopPropagation()` on the card to prevent backdrop-click-close.
7. Score circle uses `tabular-nums` equivalent via SVG `textAnchor="middle"`.
8. Session cost uses `className="tabular-nums"` to prevent layout jitter during count-up.

---

## 14. RULE SUMMARY — DO NOT VIOLATE

```
✅ Use inline style={{ fontFamily, fontSize }} for ALL text
✅ Use inline style={{ background, border, color }} for ALL brand colours
✅ Use motion/react: import { motion, AnimatePresence } from "motion/react"
✅ Use AnimatePresence wrapping motion.* for ALL enter/exit animations
✅ Use requestAnimationFrame for score circle and useCountUp
✅ Use METIS_RED, DARK_BG, PANEL_BG constants from data file
✅ Use SORTED_ISSUES (pre-sorted) everywhere issues are rendered
✅ Use computeMetrics(inputs) in render body, no useMemo
✅ Use className for layout (flex, grid, p-*, m-*, rounded-*, overflow-*, gap-*)
✅ Keep ALL state in MetisExtension root — no Context, no Zustand, no Redux

❌ Never use Tailwind text-* colour classes for brand values (text-red-500, etc.)
❌ Never use Tailwind bg-* classes for panel/modal backgrounds
❌ Never use CSS transitions for panel enter/exit (use Motion AnimatePresence)
❌ Never put AccuracyInputs form in mini or full side panels — only FullReportModal
❌ Never show Scale Simulation in mini or full panels — only FullReportModal
❌ Never show cost breakdown rows in mini panel
❌ Never use grey hex values — always use rgba(255,255,255,X) opacity variants
❌ Never use system fonts or additional Google Fonts beyond Jua + Inter
❌ Never import from "framer-motion" — always "motion/react"
```

---

## 15. FILE DEPENDENCIES MAP

```
App.tsx
  └── MetisExtension.tsx
        ├── types/metis.types.ts    (PanelMode, AccuracyInputs, MetisMetrics, CostBreakdown, IssueDefinition, StackItem)
        ├── data/metis-mock-data.ts (METIS_RED, DARK_BG, PANEL_BG, DEFAULT_INPUTS, MOCK_STACK_ITEMS,
        │                           MOCK_DETAILED_STACK, SORTED_ISSUES, DETECTION_STEPS,
        │                           DETECTION_TOTAL_DURATION_MS, PLUS_FEATURES, FREE_VS_PLUS_ROWS)
        ├── lib/scoring.ts          (computeMetrics, fmtCost, fmtMonthly, fmtTraffic)
        ├── motion/react            (motion, AnimatePresence)
        ├── lucide-react            (X, Maximize2, Minimize2, AlertCircle, AlertTriangle, Info, Zap,
        │                           ChevronRight, Loader2, Shield, Sparkles, FileText, Download,
        │                           Target, ChevronDown, TrendingDown, Lock, RefreshCw, Wrench,
        │                           LogOut, Settings, Crown, Trophy, Users, ArrowRight, Copy,
        │                           CheckCheck, Activity, Clock, Cpu)
        └── sonner                  (toast)
```

---

*End of AI_README. Every value here is taken directly from the live source code. Replicate exactly.*
