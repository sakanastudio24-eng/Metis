
  # Metis Design

  This is a code bundle for Metis Design. The original project is available at https://www.figma.com/design/wXyUMJYFWpyd8mborY6JpJ/Metis-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  