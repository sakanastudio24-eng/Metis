# Metis Extension — Complete Design Style Guide

> This document is the single source of truth for replicating the Metis Chrome extension UI. Every colour, spacing value, animation curve, typography rule, component pattern, and interaction behaviour is documented here. Nothing is left to interpretation.

---

## 1. COLOUR SYSTEM

### Core Palette

| Token | Hex | Usage |
|---|---|---|
| `METIS_RED` | `#dc5e5e` | Primary brand — CTA buttons, logo mark, Plus accents, score ring on tab button |
| `DARK_BG` | `#0c1623` | Deepest layer — app root, modal backdrops, tooltips, tab button body |
| `PANEL_BG` | `#111d2b` | Panel layer — mini panel, full panel backgrounds. Slightly lighter than DARK_BG |
| Modal BG | `#0d1825` | Upgrade modal and full report modal body. Mid-point between DARK_BG and PANEL_BG |

### Risk Tier Colours

The entire UI adapts its accent colour based on the current risk score. These four states drive the score ring, risk badge, pulsing dot, and hover tooltip indicator.

| Tier | Score Range | Foreground | Background (badge) |
|---|---|---|---|
| High Risk | ≥ 80 | `#ef4444` | `rgba(239,68,68,0.2)` |
| Moderate Risk | 60–79 | `#f97316` | `rgba(249,115,22,0.2)` |
| Low Risk | 40–59 | `#eab308` | `rgba(234,179,8,0.2)` |
| Minimal Risk | < 40 | `#22c55e` | `rgba(34,197,94,0.2)` |

### Severity Colours (Issues)

| Severity | Foreground | Use |
|---|---|---|
| Critical | `#ef4444` | AlertCircle icon, dot, badge background `#ef444422` |
| Moderate | `#f97316` | AlertTriangle icon, dot, badge background `#f9731622` |
| Low | `#eab308` | Info icon, dot, badge background `#eab30822` |

### Semantic Accent Colours

| Purpose | Colour | Context |
|---|---|---|
| Savings / Fix confirmed | `#4ade80` (green-400) | "Save ~$X/mo" badges, ✓ checks in comparison table |
| Scale projection row | `#a5b4fc` (indigo-300) | "At 10k users →" value |
| AI cost / detection | `#10a37f` | OpenAI green — AI detection badge |
| Vercel / cost driver | `#a5b4fc` | Vercel stack badge accent |
| Live pulse dot | `#6366f1` (indigo-500) | Session cost block provenance chip dot |
| Export PDF button (Plus) | `#60a5fa` (blue-400) | Export PDF button background + text |
| Priority #1 trophy | `#ffd700` (gold) | "Fix First" badge, trophy icon |
| Coming Soon badge | `#a5b4fc` | Feature card tag |

### White Opacity Scale

The entire dark UI uses a single white (`#ffffff`) with opacity variants — never grey hex values directly.

| Opacity | `rgba` value | Usage |
|---|---|---|
| `/70` | `rgba(255,255,255,0.70)` | Tooltip body text |
| `/65` | `rgba(255,255,255,0.65)` | Stack chip labels, cost row labels |
| `/60` | `rgba(255,255,255,0.60)` | Quick insight text, secondary body |
| `/55` | `rgba(255,255,255,0.55)` | Form labels, issue titles in comparison table |
| `/50` | `rgba(255,255,255,0.50)` | Session cost label, muted body |
| `/45` | `rgba(255,255,255,0.45)` | Issue descriptions, feature card descriptions |
| `/40` | `rgba(255,255,255,0.40)` | Icon colours (X, minimize, maximize), subtle labels |
| `/38` | `rgba(255,255,255,0.38)` | Feature card body text |
| `/35` | `rgba(255,255,255,0.35)` | Scanning text, profile email, panel URL |
| `/30` | `rgba(255,255,255,0.30)` | Section labels (uppercase), detection status text |
| `/28` | `rgba(255,255,255,0.28)` | Section subheadings in report |
| `/25` | `rgba(255,255,255,0.25)` | Issue rank numbers (#2, #3), stack category labels |
| `/20` | `rgba(255,255,255,0.20)` | Footer branding text, disclaimer text |
| `/18` | `rgba(255,255,255,0.18)` | Score ring track stroke |
| `/15` | `rgba(255,255,255,0.15)` | Locked "—" dash in comparison table |

### Surface / Layer Backgrounds (inline `rgba`)

| Surface | Value | Usage |
|---|---|---|
| Card row (on dark) | `rgba(255,255,255,0.04)` | Cost breakdown rows, what-just-happened header |
| Card row (on panel) | `rgba(255,255,255,0.06)` | Stack chips, form select bg, mini issue row divider |
| Card hover (on dark) | `rgba(255,255,255,0.07)` | FullIssueRow hover, WhatJustHappened open state |
| Card hover (on panel) | `rgba(255,255,255,0.14)` | FullIssueRow hover on lighter bg |
| Input / select bg | `rgba(255,255,255,0.06)` | SelectField, PillGroup inactive |
| Quick insight box | `rgba(255,255,255,0.05)` | Quick insight card in mini panel |
| Report section bg | `rgba(255,255,255,0.03)` | ImproveAccuracyForm wrapper, "Free" mental model column |
| Subtle row stripe | `rgba(255,255,255,0.015)` | Alternating row in scale simulation table |
| Score backdrop | `rgba(255,255,255,0.02)` | Issue card body in fix recommendations |
| Divider borders | `rgba(255,255,255,0.04)` – `rgba(255,255,255,0.1)` | Row separators, section dividers |
| Panel border | `rgba(255,255,255,0.07)` – `rgba(255,255,255,0.1)` | Panel outer borders |

### Brand-coloured Surfaces

| Purpose | Value |
|---|---|
| Plus section / refined output bg | `rgba(220,94,94,0.08)` |
| Plus section border | `rgba(220,94,94,0.2)` |
| Plus badge bg | `rgba(220,94,94,0.18)` |
| Plus badge border | `rgba(220,94,94,0.3)` |
| Plus badge border (strong) | `rgba(220,94,94,0.35)` |
| #1 issue border | `issue.color + "55"` (35% opacity hex) |
| Other issue borders | `issue.color + "25"` (15% opacity hex) |
| Savings badge bg | `rgba(34,197,94,0.15)` |
| Scale row (AI) | `rgba(16,163,127,0.08)` |
| Scale row border | `rgba(16,163,127,0.15)` |
| AI badge bg | `rgba(16,163,127,0.15)` |
| AI badge border | `rgba(16,163,127,0.3)` |
| Session cost scale row | `rgba(99,102,241,0.07)` |
| Session cost scale border | `rgba(99,102,241,0.15)` |

---

## 2. TYPOGRAPHY

### Font Families

Two fonts only. No system fonts except as fallbacks.

```css
@import url('https://fonts.googleapis.com/css2?family=Jua&family=Inter:wght@400;500;600;700&display=swap');
```

| Font | Family string | Role |
|---|---|---|
| **Jua** | `"Jua, sans-serif"` | Display / numerics — score numbers, panel titles, "Metis" wordmark, prices, cost values |
| **Inter** | `"Inter, sans-serif"` | Everything else — body, labels, badges, descriptions, buttons |

### Type Scale (inline `fontSize` values in px)

All font sizes are applied via inline `style={{ fontFamily: "...", fontSize: N }}` — never Tailwind text-* classes unless overriding.

| Size (px) | Usage |
|---|---|
| `42` | Score number in Full Report modal overview (Jua) |
| `36` | Price in upgrade modal (Jua) |
| `28` | Score number in full side panel (Jua) |
| `24` | "Welcome to Metis+" success heading (Jua) |
| `22` | Upgrade modal main heading (Jua) |
| `20` | Quiz heading (Inter, weight 700) |
| `18` | "M" glyph in full panel header (Jua); tab button M (Jua) |
| `16` | "M" in full report modal header (Jua); refined output cost value (Jua) |
| `15` | Cost range in report overview (Jua); session cost in block (Jua, non-compact) |
| `14` | Panel title "Metis" / "Metis Scan" (Jua); "Metis+" badge (Jua); avatar dropdown price (Jua) |
| `13` | Profile dropdown user name (Inter); upgrade CTA button (Inter) |
| `12` | Standard body — issue titles, cost row labels, form labels, button text, report subheadings (Inter) |
| `11` | Small body — quick insight, description text, section labels (Inter) |
| `10` | Tiny — root cause/fix labels, scale table labels, report footer, "Most Important" badge (Inter) |
| `9` | Micro — severity badges, savings badge, stack detection badge labels (Inter) |
| `8` | Nano — priority rank numbers, "Fix First" badge, "now" pill in scale table (Inter) |

### Font Weights (Inter only)

| Weight | Tailwind / CSS | Usage |
|---|---|---|
| `400` | `font-normal` | Body text, descriptions |
| `500` | `font-medium` | Default button weight (theme.css global) |
| `600` | `font-semibold` | Section labels, issue titles, form field labels, badge text |
| `700` | `font-bold` | Panel title, score numbers, cost values, CTA buttons, profile name |

Jua has only one weight (regular/400) but renders as display weight visually.

### Letter Spacing

Section labels use `letterSpacing: "0.1em"` (wide tracking). All caps labels in report use `letterSpacing: "0.05em"` to `"0.08em"`. Default body text uses no letter spacing.

---

## 3. SPACING & LAYOUT

### Extension Panel Dimensions

| Panel | Width | Position | Margin |
|---|---|---|---|
| Tab button | `44px` min-width | `fixed right-0`, `bottom: 5rem` | Flush to viewport right edge |
| Mini panel | `288px` | `fixed right-0 top-0 bottom-0` | Flush to viewport right edge |
| Full panel | `410px` | `fixed right-5 top-5 bottom-5` | 20px inset from viewport edges |
| Full report modal | `max-w-2xl` (672px) | `fixed inset-0`, centered | `p-6` (24px) padding on container |
| Upgrade modal | `max-w-xl` (576px) | `fixed inset-0`, centered | `p-5` (20px) padding on container |

### Panel Internal Padding

| Context | Padding |
|---|---|
| Mini panel header | `px-4 pt-4 pb-3` |
| Mini panel body | `px-4 py-4` |
| Mini panel footer | `px-4 pb-4 pt-3` |
| Full panel header | `px-5 pt-5 pb-4` |
| Full panel sections | `px-5 py-5` |
| Full panel footer | `px-5 pb-5 pt-3` |
| Report modal header | `px-6 py-5` |
| Report modal sections | `px-6 py-6` |
| Report modal footer | `px-6 py-4` |
| Upgrade modal header | `px-6 pt-6 pb-5` |
| Upgrade modal body | `px-6 py-5` |
| Upgrade modal CTA footer | `px-6 pb-6 pt-4` |

### Gap / Space Scale

| Usage | Value |
|---|---|
| Stack chips gap | `gap-1.5` (6px) |
| Icon + label | `gap-1.5` (6px) |
| Section label icon + text | `gap-1.5` (6px) |
| Issue row internal | `gap-2` (8px) |
| Header elements | `gap-2` – `gap-3` |
| Panel header icon + title | `gap-3` (12px) |
| Report overview score + text | `gap-6` (24px) |
| Vertical body spacing | `space-y-2` – `space-y-5` |
| Form fields | `space-y-5` (20px) |
| Feature grid | `gap-2.5` (10px) |

---

## 4. BORDER RADIUS

All border radii are applied via inline `style` or Tailwind `rounded-*`. Never mix.

| Value | Tailwind | Inline px | Usage |
|---|---|---|---|
| 4px | `rounded` | — | Micro elements |
| 6px | `rounded-md` | — | Small badges |
| 8px | `rounded-lg` | — | Severity count pills, avatar initials icon |
| 12px | `rounded-xl` | — | Quick insight box, cost rows, form selects, WhatJustHappened, CopyReportButton, issue tooltips, copy/export buttons |
| 16px | `rounded-2xl` | `16` | Issue cards, feature cards, comparison table, form wrapper, refined output, scale simulation, profile dropdown, CTA buttons |
| 20px | `rounded-3xl` | `22` | Full report modal (`borderRadius: 22`) |
| 24px | `rounded-3xl` | `24` | Upgrade modal (`borderRadius: 24`) |
| Full | `rounded-full` | — | Badges, pills, dots, avatar, billing toggle, risk badge, stack chips, tab button pulse ring |

Tab button: `borderRadius: "12px 0 0 12px"` — intentionally flat on right side (attached to viewport edge).

---

## 5. BORDERS

All borders use inline `style` with `rgba` values — never Tailwind `border-*` colour classes.

| Type | Value |
|---|---|
| Panel outer border | `1px solid rgba(255,255,255,0.07)` |
| Panel left edge (mini) | `1px solid rgba(255,255,255,0.06)` |
| Section dividers | `1px solid rgba(255,255,255,0.08)` |
| Report section dividers | `1px solid rgba(255,255,255,0.06)` |
| Card / row borders | `1px solid rgba(255,255,255,0.07)` – `rgba(255,255,255,0.1)` |
| Input / select border | `1px solid rgba(255,255,255,0.1)` |
| Tab button border | `1px solid rgba(255,255,255,0.1)` — no right border |
| Plus badge border | `1px solid rgba(220,94,94,0.3)` |
| Issue #1 card border | `1px solid ${issue.color}55` |
| Other issue borders | `1px solid ${issue.color}25` |
| Fix code block border-left | `3px solid ${issue.color}` |
| Mini issue fix hint border-left | `2px solid ${issue.color}40` |
| Profile dropdown | `1px solid rgba(255,255,255,0.1)` |
| Tooltip | `1px solid ${issue.color}40` |
| Upgrade modal | `1px solid rgba(255,255,255,0.09)` |
| Billing toggle wrapper | `1px solid rgba(255,255,255,0.08)` |
| Form wrapper | `1px solid rgba(255,255,255,0.07)` |
| Refined output | `1px solid rgba(220,94,94,0.2)` |
| Session cost block | `1px solid rgba(255,255,255,0.08)` |

---

## 6. SHADOWS

| Element | Shadow |
|---|---|
| Tab button | `shadow-2xl` |
| Mini panel | `shadow-2xl` |
| Full panel | `shadow-2xl` |
| Full report modal | `boxShadow: "0 40px 100px rgba(0,0,0,0.6)"` |
| Upgrade modal | `boxShadow: "0 48px 120px rgba(0,0,0,0.7)"` |
| Profile dropdown | `boxShadow: "0 20px 56px rgba(0,0,0,0.55)"` |
| Issue tooltip | `boxShadow: "0 8px 32px rgba(0,0,0,0.5), 0 0 0 1px ${issue.color}20"` |
| Upgrade CTA button | `boxShadow: "0 8px 24px rgba(220,94,94,0.35)"` |
| Issue #1 card | `boxShadow: "0 0 20px ${issue.color}10"` |

---

## 7. ICONS

Library: **lucide-react** exclusively.

### Icon Sizing

| Context | Size (px) |
|---|---|
| Section label icons | `11` |
| Mini panel header (X, maximize) | `12` |
| Full panel header (minimize, X) | `12` |
| CTA button icons | `12` |
| Issue row icons | `13` |
| Score changed badge | n/a (arrows are unicode) |
| Copy/check icons | `13` |
| WhatJustHappened row icons | `10` |
| Scale simulation user icon | `10` |
| Crown in badge | `8` – `12` depending on context |
| Trophy in priority #1 | `8` – `9` |
| TrendingDown in tooltip | `9` |
| Report modal close X | `15` |
| Plus modal close X | `14` |
| Feature card icons | `13` |
| LoadingScreen spinner | `14` |

### Icon Colours

Icons never use Tailwind colour classes unless referencing opacity. They use `className="text-white/40"` style opacity variants or inline `style={{ color: "..." }}` for brand colours.

| Context | Colour |
|---|---|
| Panel control icons (X, min, max) | `text-white/40` |
| Section label icon | `text-white/30` |
| Crown (Plus badge) | `METIS_RED` (`#dc5e5e`) |
| Issue icon | `issue.color` (matches severity) |
| Tooltip trending icon | `issue.color` |
| Lock icon | `text-white` (full white) |
| Feature card icon | `f.color` (per-feature colour) |
| WhatJustHappened icons | `ev.color` (per-event colour) |
| CopyReportButton (idle) | `rgba(255,255,255,0.5)` |
| CopyReportButton (copied) | `#4ade80` |
| Scale simulation user icon | `text-white/25` |

---

## 8. ANIMATION SYSTEM

### Motion Library

All animations use **Motion** (`motion/react`) — `import { motion, AnimatePresence } from "motion/react"`.

**Never use CSS transitions** for enter/exit. Always use `AnimatePresence` wrapping `motion.*` elements.

### Panel Entry / Exit

```tsx
// Mini panel — slides from right edge
initial={{ x: 310, opacity: 0 }}
animate={{ x: 0, opacity: 1 }}
exit={{ x: 310, opacity: 0 }}
transition={{ type: "spring", stiffness: 340, damping: 30 }}

// Full panel — scales + slides from right
initial={{ x: 50, opacity: 0, scale: 0.97 }}
animate={{ x: 0, opacity: 1, scale: 1 }}
exit={{ x: 50, opacity: 0, scale: 0.97 }}
transition={{ type: "spring", stiffness: 340, damping: 30 }}

// Tab button — slides from off-screen right
initial={{ x: 80, opacity: 0 }}
animate={{ x: 0, opacity: 1 }}
exit={{ x: 80, opacity: 0 }}
transition={{ type: "spring", stiffness: 380, damping: 28 }}

// Report modal — scale from center
initial={{ scale: 0.9, y: 28, opacity: 0 }}
animate={{ scale: 1, y: 0, opacity: 1 }}
exit={{ scale: 0.9, y: 28, opacity: 0 }}
transition={{ type: "spring", stiffness: 360, damping: 28 }}

// Upgrade modal — scale from center (more spring)
initial={{ scale: 0.88, y: 32, opacity: 0 }}
animate={{ scale: 1, y: 0, opacity: 1 }}
exit={{ scale: 0.88, y: 32, opacity: 0 }}
transition={{ type: "spring", stiffness: 380, damping: 30 }}
```

### Score Circle Animation

Uses `requestAnimationFrame` with **cubic ease-out**: `eased = 1 - Math.pow(1 - t, 3)`. Duration: `750ms`. Animates the SVG `strokeDashoffset` and the text number simultaneously. The circle stroke transitions at `0.04s linear` — very fast to feel live during the RAF-driven count.

### Count-Up (useCountUp hook)

```tsx
// Same cubic ease-out, counts from 0 to target
// sessionCost: duration 950ms
// monthlyAt10k: duration 1100ms
// Both reset to 0 and re-count on every target change
eased = 1 - Math.pow(1 - t, 3)
```

### Loading Screen Stagger

Each detection step appears at a fixed delay (ms): `[0, 280, 520, 700, 860, 1010, 1160, 1320]`. Each item animates: `initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.25, ease: "easeOut" }}`. Dots use spring: `stiffness: 500, damping: 20`.

### Risk Badge Animation

```tsx
// Re-mounts with AnimatePresence mode="wait" when riskLabel changes
initial={{ opacity: 0, scale: 0.9 }}
animate={{ opacity: 1, scale: 1 }}
transition={{ duration: 0.3 }}

// Internal pulsing dot
animate={{ opacity: [1, 0.35, 1] }}
transition={{ duration: 1.8, repeat: Infinity }}
```

### Tab Button Risk Pulse Ring

```tsx
// Only renders when score >= 60
animate={{
  boxShadow: [
    `inset 0 0 0px 0px ${riskColor}00`,
    `inset 0 0 12px 2px ${riskColor}40`,
    `inset 0 0 0px 0px ${riskColor}00`,
  ],
}}
transition={{ duration: 2.2, repeat: Infinity, ease: "easeInOut" }}
```

### Tab Button Risk Dot Pulse

```tsx
// Only when score >= 70
animate={{ scale: [1, 1.5, 1], opacity: [1, 0.6, 1] }}
transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
```

### Tab Button Hover

```tsx
whileHover={{ x: -3 }}  // nudges left 3px
whileTap={{ scale: 0.95 }}
transition={{ type: "spring", stiffness: 400, damping: 22 }}
```

### Tooltip Appear

```tsx
initial={{ opacity: 0, y: 4, scale: 0.97 }}
animate={{ opacity: 1, y: 0, scale: 1 }}
exit={{ opacity: 0, y: 4, scale: 0.97 }}
transition={{ duration: 0.15 }}
```

### Profile Dropdown

```tsx
initial={{ opacity: 0, y: -8, scale: 0.94 }}
animate={{ opacity: 1, y: 0, scale: 1 }}
exit={{ opacity: 0, y: -8, scale: 0.94 }}
transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
```

### Hover Tooltip (issue rows)

Positioned `bottom: calc(100% + 6px)` above the row. Arrow triangle is `w-2.5 h-2.5 rotate-45` absolutely positioned at `bottom: -5px, left: 16px`.

### WhatJustHappened Expand

```tsx
initial={{ opacity: 0, height: 0 }}
animate={{ opacity: 1, height: "auto" }}
exit={{ opacity: 0, height: 0 }}
transition={{ duration: 0.22 }}
style={{ overflow: "hidden" }}
```

ChevronDown inside rotates: `animate={{ rotate: open ? 180 : 0 }} transition={{ duration: 0.2 }}`.

### Collapsible Smart Warning (issue hover)

```tsx
initial={{ opacity: 0, height: 0 }}
animate={{ opacity: 1, height: "auto" }}
exit={{ opacity: 0, height: 0 }}
// No explicit transition — uses default
```

### Refined Output Expand

```tsx
initial={{ opacity: 0, height: 0, y: 8 }}
animate={{ opacity: 1, height: "auto", y: 0 }}
exit={{ opacity: 0, height: 0, y: 8 }}
transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
style={{ overflow: "hidden" }}
```

### Staggered List Items

Issue rows, feature cards, scale scenarios all stagger with `delay: 0.04 * i` or `0.06 * i`. Cost breakdown rows: `delay: delay + i * 0.06`. Stack chips: `delay: delay + i * 0.04`.

### Button Interactions

```tsx
// Primary CTA buttons
whileHover={{ scale: 1.02 }}
whileTap={{ scale: 0.97 }}

// Small buttons / pills
whileHover={{ scale: 1.04 }}
whileTap={{ scale: 0.97 }}

// Avatar button
whileHover={{ scale: 1.08 }}
whileTap={{ scale: 0.93 }}

// CopyReportButton
whileHover={{ scale: 1.04 }}
whileTap={{ scale: 0.93 }}
```

### Copy Button Icon Swap

Uses `AnimatePresence mode="wait"`. Copy → CheckCheck: `initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }}`. Both icons use the same spring. Reverts after 2000ms.

### Plus Upgrade Success Animation

1. Backdrop fades to full-screen `background: "#0d1825"` with `opacity: 0 → 1, duration: 0.3`
2. Crown circle: `initial={{ scale: 0, rotate: -20 }} → animate({ scale: 1, rotate: 0 })` with `type: "spring", stiffness: 420, damping: 22, delay: 0.1`
3. Five sparkle dots orbit the crown at 72° increments: `scale: [0,1,0]`, staggered `delay: 0.25 + i * 0.06`, `duration: 0.7`
4. Text fades up: `initial={{ opacity: 0, y: 12 }} → animate({ opacity: 1, y: 0 }), delay: 0.3`
5. Progress bar fills: `width: "0%" → "100%"`, `duration: 1.6, delay: 0.4, ease: "easeInOut"`
6. After `1800ms`, `onConfirm()` is called.

### Billing Toggle (Upgrade Modal)

Uses `layoutId="billing-pill"` on the active indicator pill — Motion automatically animates the sliding background between options using spring physics: `stiffness: 500, damping: 35`.

### Score Changed Badge (delta indicator)

```tsx
initial={{ opacity: 0, y: -6, scale: 0.85 }}
animate={{ opacity: 1, y: 0, scale: 1 }}
exit={{ opacity: 0, scale: 0.85 }}
transition={{ duration: 0.3 }}
```

### Numeric Value Updates (cost rows, prices)

When a value changes (e.g., score adjustment updates cost breakdown), the number re-mounts via `key={value}`:
```tsx
initial={{ opacity: 0, y: -4 }}
animate={{ opacity: 1, y: 0 }}
transition={{ duration: 0.35 }}
```
For larger values: `initial={{ opacity: 0, x: 8 }}` instead.

### LoadingScreen Spinner

```tsx
animate={{ rotate: 360 }}
transition={{ duration: 1.2, repeat: Infinity, ease: "linear" }}
```

### Session Cost Live Dot

```tsx
animate={{ opacity: [1, 0.4, 1] }}
transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
```

---

## 9. COMPONENT PATTERNS

### Score Circle (SVG)

- `viewBox="0 0 {size} {size}"` — always square
- Track circle: `stroke: trackColor, strokeWidth: 5.5`
- Progress circle: `stroke: strokeColor, strokeWidth: 5.5, strokeLinecap: "round"`
- Start position: `rotate(-90 ${cx} ${cy})` — 12 o'clock
- Score text: centered via `textAnchor="middle" dominantBaseline="central"`, font `Jua`, size `size * 0.24`
- Ring radius: `r = size / 2 - 8` — 8px inset from edge

### RiskBadge

- `inline-flex items-center gap-1.5 rounded-full`
- Padding: small `"3px 10px"`, regular `"4px 12px"`
- Background: `metrics.riskBg`
- Pulsing dot: `w: small ? 6 : 7, h: small ? 6 : 7`
- Text: `small ? 10 : 11` px

### SectionLabel

- `flex items-center gap-1.5 mb-3`
- Optional icon at `size={11}` with `className="text-white/30"`
- Text: `text-white/30 text-xs uppercase tracking-widest font-semibold`
- `letterSpacing: "0.1em"` on the span

### MiniIssueRow

- Full width flex row with `py-1.5 cursor-default`
- Bottom border: `1px solid rgba(255,255,255,0.06)` (on dark) or `0.1` (on light)
- Left dot: `w-1.5 h-1.5 rounded-full` in `issue.color`
- Title: `text-white text-xs`
- Severity badge: `rounded-full px-1.5 py-0.5`, background `issue.color + "22"`, text `issue.color`, `fontSize: 9`
- Hover triggers `IssueTooltip` — positioned above via `bottom: calc(100% + 6px)`, `z-50`

### FullIssueRow

- `rounded-xl p-3 flex items-start gap-3 cursor-default`
- Background transitions: normal → hover `transition: "background 0.15s"`
- Icon at `size={13}` left-aligned with `shrink-0 mt-0.5`
- Title `fontSize: 12 font-semibold` + severity badge inline
- Description `text-white/45 mt-0.5 leading-relaxed fontSize: 11`
- Smart warning on hover: italic, `fontSize: 10`, colour `issue.color + "cc"`, begins with "⚠"

### StackChips

- `flex flex-wrap gap-1.5`
- Each chip: `flex items-center gap-1.5 rounded-full px-2.5 py-1`
- Brand dot: `w-1.5 h-1.5 rounded-full` in `item.color`
- Label: `text-white/65`, `fontSize: 11`
- Compact overflow chip: `+N more` in `text-white/30`

### CostBreakdownRows

- Three rows: Bandwidth `↕`, Requests `⚡`, AI `🤖`
- Row: `flex items-center justify-between rounded-xl px-4 py-2.5`
- Value animates via `key={row.value}` re-mount
- Total row: `flex items-center justify-between px-4 pt-1`, no background
- Total value: `Jua fontSize: 14`

### SessionCostBlock

- Container: `rounded-xl overflow-hidden border: 1px solid rgba(255,255,255,0.08)`
- Provenance chip: `flex items-center gap-1.5 px-3 py-1.5 background: rgba(255,255,255,0.04) borderBottom`
- Live dot: indigo-500, pulsing opacity
- Cost row: `px-3 py-2.5 flex items-center justify-between background: rgba(255,255,255,0.03)`
- Cost value: `Jua`, `compact ? 13 : 15` px, `tabular-nums`
- Scale row: `px-3 py-2 flex items-center gap-2 background: rgba(99,102,241,0.07) borderTop: rgba(99,102,241,0.15)`
- Scale value: `Jua fontSize: 11 color: #a5b4fc`

### PremiumSection (lock gate)

- Outer: `relative rounded-2xl overflow-hidden`
- Blurred preview: `filter: "blur(4px)" pointerEvents: "none" userSelect: "none"`
- Overlay: `absolute inset-0 flex flex-col items-center justify-center gap-3 background: rgba(12,22,35,0.7) backdropFilter: blur(3px)`
- Lock icon in `rounded-full p-2.5 background: rgba(255,255,255,0.1)`
- "Upgrade to Plus" button: `METIS_RED bg, rounded-full px-4 py-1.5, Sparkles icon`

### ProfileButton

- Avatar: `w-7 h-7 rounded-full`, background varies by context (`onDark`)
- Initials: `Inter fontSize: 10 font-bold`
- Dropdown: `w-52 rounded-2xl`, positioned `top-full mt-2 right-0 z-[200]`
- User row: `px-4 py-3.5`, large avatar `w-9 h-9 rounded-full bg: METIS_RED`
- Plan row: `px-4 py-2.5 flex items-center justify-between`
- Menu items: `w-full flex items-center gap-2.5 px-4 py-2.5`, hover background `rgba(255,255,255,0.05)`

### WhatJustHappened

- Toggle: `w-full flex items-center justify-between px-3 py-2 rounded-xl cursor-pointer`
- Open state bg: `rgba(255,255,255,0.07)`, closed: `rgba(255,255,255,0.04)`
- Event rows: `flex items-center justify-between px-3 py-2`, icon at size 10, label at `fontSize: 10`, value in `Jua fontSize: 10` in `ev.color`

### ImproveAccuracyForm

- Wrapper: `rounded-2xl p-5 space-y-5 background: rgba(255,255,255,0.03) border: rgba(255,255,255,0.07)`
- Header: `Target icon + "Improve Accuracy" label + "· updates score in real-time" dim text`
- PillGroup active: `background: rgba(249,115,22,0.25) border: rgba(249,115,22,0.5) color: #f97316`
- PillGroup inactive: `background: rgba(255,255,255,0.06) border: rgba(255,255,255,0.1) color: rgba(255,255,255,0.55)`
- Traffic slider fill: `linear-gradient(to right, rgba(255,255,255,0.6) ${pct}%, rgba(255,255,255,0.1) ${pct}%)`

### SelectField

- `appearance-none rounded-xl px-3 py-2.5 pr-8`
- Chevron overlay: `absolute right-3 top-1/2 -translate-y-1/2 text-white/30 pointer-events-none`
- Option backgrounds: `background: "#0c1623"` (placeholder), `"#162030"` (options)

### ScaleSimulation Table

- Container: `rounded-xl overflow-hidden border: rgba(255,255,255,0.07)`
- Header row: 3 cols, `background: rgba(255,255,255,0.04)`
- Data rows: alternating `transparent` / `rgba(255,255,255,0.015)`, baseline row `rgba(220,94,94,0.06)`
- Cost colour escalation: mult < 10 → `rgba(255,255,255,0.75)`, mult ≥ 10 → `#f97316`, mult ≥ 50 → `#ef4444`
- "now" pill: `background: rgba(220,94,94,0.18) color: METIS_RED fontSize: 8`

### Fix Recommendation Card (Plus)

- Container: `rounded-2xl overflow-hidden`
- Header: `flex items-center justify-between px-4 py-3 background: issue.color + "20"` (first) or `"12"`
- Priority: 20px circle, gold for #1 (Trophy icon), white/08 for others (rank number)
- "Fix First" tag: gold colours, Trophy icon at size 8
- Savings badge: `rounded-full px-2.5 py-1 background: rgba(34,197,94,0.15) color: #4ade80`
- Body: `px-4 py-3 space-y-2.5 background: rgba(255,255,255,0.02)`
- Root Cause: label `text-white/30 fontSize: 10 tracking-0.05em`, text `text-white/55 fontSize: 11 leading-relaxed`
- Fix block: `rounded-xl px-3 py-2.5 background: rgba(255,255,255,0.04) borderLeft: 3px solid issue.color`
- Scale impact: `TrendingDown icon (indigo-400) + italic text-white/35 fontSize: 10`

---

## 10. STRUCTURAL LAYOUT PATTERNS

### Modal Anatomy

Every modal (`FullReportModal`, `PlusUpgradeModal`) follows this structure:
```
fixed inset-0 backdrop (z-90 / z-300)
fixed inset-0 flex center wrapper (z-100 / z-310, pointer-events-none)
  motion.div modal card (pointer-events-auto)
    header (shrink-0, borderBottom)
    flex-1 overflow-y-auto body
    footer (shrink-0, borderTop)
```

### Panel Anatomy

Mini and Full panels:
```
fixed positioned container (AnimatePresence)
  flex flex-col h-full
    header (shrink-0, borderBottom)
    AnimatePresence mode="wait"
      LoadingScreen OR
      flex-1 overflow-y-auto content
    footer (shrink-0, borderTop)
```

### Z-Index Stack

| Layer | z-index |
|---|---|
| Full panel backdrop | `z-40` |
| Tab button / panels | `z-50` |
| Profile dropdown | `z-[200]` |
| Report modal backdrop | `z-[90]` |
| Report modal | `z-[100]` |
| Upgrade modal backdrop | `z-[300]` |
| Upgrade modal | `z-[310]` |
| Issue tooltip | `z-50` |

### Scrollbar Styling

Mini panel body: `scrollbarWidth: "none"` (hidden scrollbar).
Full panel + report modal: `scrollbarWidth: "thin", scrollbarColor: "rgba(255,255,255,0.1) transparent"`.

---

## 11. BACKDROP PATTERNS

| Context | Background | Blur |
|---|---|---|
| Full panel backdrop | `rgba(0,0,0,0.2)` | `backdropFilter: blur(3px)` |
| Report modal backdrop | `rgba(0,0,0,0.72)` | `backdropFilter: blur(16px)` |
| Upgrade modal backdrop | `rgba(0,0,0,0.78)` | `backdropFilter: blur(18px)` |
| Premium section overlay | `rgba(12,22,35,0.7)` | `backdropFilter: blur(3px)` |

---

## 12. LOADING STATE BEHAVIOUR

Every panel (`MiniPanelContent`, `FullPanelContent`, `FullReportModal`) shows a `LoadingScreen` for a fixed duration before revealing content:

| Panel | Duration |
|---|---|
| Mini panel | `1100ms` (DETECTION_TOTAL_DURATION_MS) |
| Full panel | `1100ms` |
| Full report modal | `900ms` |

Transition uses `AnimatePresence mode="wait"` with `key="loading"` / `key="content"`.

---

## 13. DETECTION FEED (LoadingScreen)

Eight steps in sequence. The colour and dot presence communicate issue severity:

```
0ms    "Scanning network requests…"       rgba(255,255,255,0.3)   no dot
280ms  "DOM analysis running…"            rgba(255,255,255,0.3)   no dot
520ms  "AI usage detected ⚠"             #f97316                  orange dot
700ms  "Duplicate API calls found"        #ef4444                  red dot
860ms  "Memory leak pattern detected"     #ef4444                  red dot
1010ms "3 unoptimized images identified"  #f97316                  orange dot
1160ms "Missing cache headers found"      #eab308                  yellow dot
1320ms "Calculating cost risk score…"     rgba(255,255,255,0.3)   no dot
```

---

## 14. TECH STACK ITEMS & BRAND COLOURS

```ts
{ name: "React 18",         color: "#61dafb", category: "Framework"  }
{ name: "Next.js 14",       color: "#aaaaaa", category: "Framework"  }
{ name: "Vercel",           color: "#6366f1", category: "Hosting"    }
{ name: "OpenAI API",       color: "#10a37f", category: "AI"         }
{ name: "Stripe",           color: "#6772e5", category: "Payment"    }
{ name: "Google Analytics", color: "#f9a825", category: "Analytics"  }
{ name: "Cloudflare CDN",   color: "#f6821f", category: "CDN"        }
```

Compact mode shows first 4 + "+3 more" chip.

---

## 15. ATMOSPHERIC EFFECTS

### Glow Blobs (Upgrade Modal Header)

```tsx
// Centred top radial glow behind header content
position: absolute
top-0 left-1/2 -translate-x-1/2
w-48 h-16 rounded-full pointer-events-none
background: "radial-gradient(ellipse, rgba(220,94,94,0.22) 0%, transparent 70%)"
filter: blur(20px)
```

### Success Screen Glow (After Upgrade)

```tsx
// Full modal glow behind success content
position: absolute inset-0 rounded-3xl pointer-events-none
background: "radial-gradient(ellipse at 50% 40%, rgba(220,94,94,0.18) 0%, transparent 65%)"
```

---

## 16. ISSUE DATA STRUCTURE

Each issue has: `severity`, `title`, `desc`, `icon` (lucide), `color`, `baseImpact` ($/mo), `rootCause`, `fix`, `saving` ($/mo), `scaleImpact`.

Sort order for display: **critical (0) → moderate (1) → low (2)**.

The first issue in sorted order (`SORTED_ISSUES[0]`) always gets:
- Gold trophy icon instead of rank number
- "Fix First" gold badge
- Stronger border opacity (`color + "55"` vs `color + "25"`)
- Stronger header background (`color + "20"` vs `color + "12"`)
- A faint glow shadow: `0 0 20px ${color}10`

---

## 17. PLUS UPGRADE PRICING

| Billing | Price | Label |
|---|---|---|
| Annual | `$7/mo` | "billed annually" |
| Monthly | `$9/mo` | (no label) |
| Annual savings badge | "Save 22%" | `background: rgba(34,197,94,0.2) color: #4ade80 fontSize: 9` |

---

## 18. FREE VS PLUS FEATURE GATES

| Feature | Free | Plus |
|---|---|---|
| Cost Risk Score | ✓ | ✓ |
| Quick Insight | ✓ | ✓ |
| Top 3 Issues (label only) | ✓ | ✓ |
| Session Cost Estimate | ✓ | ✓ |
| Full Issue Descriptions | — | ✓ |
| Fix Recommendations | — | ✓ |
| Savings per Fix | — | ✓ |
| Multi-Page Scan (50 pages) | — | ✓ |
| Scale Impact Preview | — | ✓ |
| Root Cause Analysis | — | ✓ |
| Full PDF Export | — | ✓ |

Mini panel: shows top 3 issues (Free) or all 5 with fix hints + savings (Plus).
Full panel: locked blurred section (Free) or Fix Recommendations (Plus).
Full report: same gate on Section 7, plus Scale Simulation in Section 2b (Plus only).

---

## 19. COPY REPORT FORMAT

Plain text format written to clipboard:
```
Metis Cost Report — app.example.com
Risk Score: {score}/100 ({riskLabel})
Estimated waste: ~${costRangeMin}–${costRangeMax}/month
Session cost: {fmtCost(sessionCost)} · At 10k users: ~{fmtMonthly(monthlyAt10k)}/month
Top issues: {issue1}, {issue2}, {issue3}
Quick insight: {quickInsight}
— Scanned by Metis (metis.ward.studio)
```

Toast: `position="bottom-left" theme="dark"`, message `"Report copied!"`, description `"Paste it in Slack, Notion, or a client chat."`, duration `2500ms`.

---

## 20. HOVER TOOLTIP ANATOMY

```
absolute left-0 right-0 z-50 pointer-events-none
bottom: calc(100% + 6px)         ← floats above the row

  rounded-xl px-3 py-2.5 shadow-2xl
  background: #0c1623
  border: 1px solid {issue.color}40
  boxShadow: 0 8px 32px rgba(0,0,0,0.5), 0 0 0 1px {issue.color}20

    p  text-white/70 leading-relaxed fontSize:11
    div flex items-center gap-1.5 mt-1.5
      TrendingDown size:9 color:issue.color
      span fontSize:9 color:issue.color  "~${baseImpact}/mo impact · hover for details"

  ▼ arrow div
  absolute left-4 w-2.5 h-2.5 rotate-45
  bottom: -5
  background: #0c1623
  borderBottom: 1px solid {issue.color}40
  borderRight: 1px solid {issue.color}40
```

---

## 21. SCORING ENGINE SUMMARY

**Base score: 72** (before any AccuracyInputs applied)

Adjustments stack additively:

| Input | Range |
|---|---|
| Hosting | -5 (AWS) to +6 (Netlify) |
| Plan tier | -8 (Enterprise) to +9 (Free) |
| App type | -10 (Static Site) to +15 (AI-Heavy) |
| Pages/session | -6 ("1–2") to +15 ("10+") |
| Site size | -5 (<10 pages) to +7 (200+) |
| Traffic band | -7 (<200) to +16 (≥7000) |

Final score: `clamp(1, 100, BASE_SCORE + adj)`.

Score drives: risk tier colours, cost breakdown values, quick insight text, session cost, pages scanned label (3/4/5).

---

## 22. WHAT JUST HAPPENED — EVENT DATA

Four hardcoded events:
```ts
{ icon: Activity, color: "#ef4444", label: "API requests on load",  value: "12 calls"      }
{ icon: Cpu,      color: "#f97316", label: "AI completions fired",  value: "3 calls"       }
{ icon: FileText, color: "#eab308", label: "Heavy assets loaded",   value: "3 files › 2MB" }
{ icon: Clock,    color: "#6366f1", label: "Time to interactive",   value: "3.4s"          }
```

---

## 23. STACK DETECTION BADGES (Inline)

Two badges always shown in panel footers:

```tsx
// AI badge
background: rgba(16,163,127,0.12)  border: rgba(16,163,127,0.25)
icon: 🤖 text: "AI detected · OpenAI"  color: #10a37f

// API badge
background: rgba(249,115,22,0.12)  border: rgba(249,115,22,0.25)
icon: ⚡ text: "12 API calls on load"  color: #f97316
```

Mini panel uses slightly different variant:
```tsx
// AI badge (mini panel)
background: rgba(16,163,127,0.15)  border: rgba(16,163,127,0.3)  text: "AI usage detected"

// Vercel badge (mini panel)
background: rgba(99,102,241,0.12)  border: rgba(99,102,241,0.25)  icon: ⚡  color: #a5b4fc  text: "Vercel: cost driver"
```

---

## 24. GLOBAL APP SHELL

```tsx
// App.tsx
<div className="relative min-h-screen" style={{ background: "#0c1623" }}>
  <MetisExtension />
  <Toaster position="bottom-left" theme="dark" />
</div>
```

The root background matches `DARK_BG` exactly (`#0c1623`). The `Toaster` is always `position="bottom-left"` and `theme="dark"`.

---

## 25. MENTAL MODEL (Plus vs Free)

Two-column layout in upgrade modal footer:

```
FREE column                    PLUS column
──────────────────             ──────────────────
bg: rgba(255,255,255,0.03)    bg: rgba(220,94,94,0.06)
border: rgba(255,255,255,0.06) border: rgba(220,94,94,0.2)

label: "FREE" (white/30)       Crown icon + "PLUS" (METIS_RED)

🔍 Detect                     💡 Explain
📊 Estimate                   🛠 Guide
👁 Reveal                     ⚡ Optimize

Steps connected with ArrowRight (size:8)
Free: text-white/15  |  Plus: METIS_RED + 40% opacity
```
