import { MetisExtension } from "./components/MetisExtension";
import { Toaster } from "sonner";

export default function App() {
  return (
    <div
      className="relative min-h-screen"
      style={{ background: "#0c1623" }}
    >
      <MetisExtension />
      <Toaster position="bottom-left" theme="dark" />
    </div>
  );
}