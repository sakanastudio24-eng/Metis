export default function ArrowsOutSimple() {
  return <div className="size-full" data-name="ArrowsOutSimple" />;
}