export default function Line() {
  return (
    <div className="relative size-full">
      <div className="absolute inset-[-2px_0_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 915.001 2">
          <line id="Line 1" stroke="var(--stroke-0, #D9D9D9)" strokeWidth="2" x2="915.001" y1="1" y2="1" />
        </svg>
      </div>
    </div>
  );
}