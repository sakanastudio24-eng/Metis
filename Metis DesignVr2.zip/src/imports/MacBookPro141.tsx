export default function MacBookPro() {
  return (
    <div className="bg-white relative size-full" data-name="MacBook Pro 14' - 1">
      <div className="absolute bg-[#d9d9d9] h-[125px] left-[1411px] rounded-bl-[30px] rounded-tl-[30px] top-[117px] w-[101px]" />
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Jua:Regular',sans-serif] h-[125px] justify-center leading-[0] left-[1461.5px] not-italic text-[96px] text-black text-center top-[179.5px] w-[101px]">
        <p className="leading-[normal]">M</p>
      </div>
    </div>
  );
}