import svgPaths from "./svg-r9oa22podd";

function Frame() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[6px] items-start left-[1454px] top-[324px] w-[29px]">
      <div className="bg-[#d9d9d9] h-[29px] rounded-[4px] shrink-0 w-full" />
      <div className="bg-[#d9d9d9] h-[29px] rounded-[4px] shrink-0 w-full" />
      <div className="bg-[#d9d9d9] h-[29px] rounded-[4px] shrink-0 w-full" />
      <div className="bg-[#d9d9d9] h-[29px] rounded-[4px] shrink-0 w-full" />
      <div className="bg-[#d9d9d9] h-[29px] rounded-[4px] shrink-0 w-full" />
    </div>
  );
}

export default function MacBookPro() {
  return (
    <div className="bg-white relative size-full" data-name="MacBook Pro 14' - 2">
      <div className="absolute bg-[#d9d9d9] h-[982px] left-[1192px] top-0 w-[320px]" />
      <div className="absolute bg-[#dc5e5e] h-[900px] left-[1211px] rounded-[34px] top-[62px] w-[289px]" />
      <div className="absolute bg-[#dc5e5e] h-[27px] left-[1228px] top-[19px] w-[29px]" />
      <div className="-translate-y-1/2 absolute flex flex-col font-['Jua:Regular',sans-serif] h-[27px] justify-center leading-[0] left-[1267px] not-italic text-[24px] text-black top-[32.5px] w-[155px]">
        <p className="leading-[normal]">Metis</p>
      </div>
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Jua:Regular',sans-serif] h-[29px] justify-center leading-[0] left-[1324.5px] not-italic text-[24px] text-center text-white top-[213.5px] w-[165px]">
        <p className="leading-[normal]">Score</p>
      </div>
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Jua:Regular',sans-serif] h-[29px] justify-center leading-[0] left-[1324.5px] not-italic text-[20px] text-center text-white top-[258.5px] w-[165px]">
        <p className="leading-[normal]">Issues</p>
      </div>
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Jua:Regular',sans-serif] h-[29px] justify-center leading-[0] left-[1324.5px] not-italic text-[48px] text-center text-white top-[174.5px] w-[165px]">
        <p className="leading-[normal]">86</p>
      </div>
      <div className="absolute bg-[#d9d9d9] h-[44px] left-[1224px] top-[280px] w-[201px]" />
      <div className="absolute bg-[#d9d9d9] h-[44px] left-[1224px] top-[334px] w-[201px]" />
      <div className="absolute bg-[#d9d9d9] h-[44px] left-[1224px] top-[388px] w-[201px]" />
      <div className="absolute bg-[#d9d9d9] h-[44px] left-[1224px] top-[442px] w-[201px]" />
      <div className="absolute bg-[#d9d9d9] h-[44px] left-[1224px] top-[496px] w-[201px]" />
      <div className="absolute left-[1452px] size-[37px] top-[74px]">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 37 37">
          <circle cx="18.5" cy="18.5" fill="var(--fill-0, #D9D9D9)" id="Ellipse 1" r="18.5" />
        </svg>
      </div>
      <div className="absolute border border-solid border-white h-[212px] left-[1448px] rounded-[14px] top-[302px] w-[41px]" />
      <Frame />
      <div className="absolute bg-[#d9d9d9] h-[118px] left-[1211px] top-[757px] w-[226px]" />
      <div className="absolute bg-[#d9d9d9] h-[118px] left-[1211px] top-[595px] w-[226px]" />
      <div className="absolute bg-[#d9d9d9] h-[27px] left-[1244px] top-[929px] w-[160px]" />
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Jua:Regular',sans-serif] h-[19px] justify-center leading-[0] left-[1271px] not-italic text-[15px] text-black text-center top-[774.5px] w-[106px]">
        <p className="leading-[normal]">Detected Stack</p>
      </div>
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Jua:Regular',sans-serif] h-[19px] justify-center leading-[0] left-[1280px] not-italic text-[15px] text-black text-center top-[612.5px] w-[124px]">
        <p className="leading-[normal]">Improve Accuracy</p>
      </div>
      <div className="absolute inset-[94.6%_2.35%_3.72%_96.56%]" data-name="Vector">
        <svg className="absolute block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16.5 16.5">
          <path d={svgPaths.p6e37e80} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}