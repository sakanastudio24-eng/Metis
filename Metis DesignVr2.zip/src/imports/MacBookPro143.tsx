export default function MacBookPro() {
  return (
    <div className="bg-white relative size-full" data-name="MacBook Pro 14' - 3">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute bg-[#d9d9d9] h-[854px] left-1/2 rounded-[53px] top-1/2 w-[1168px]" />
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Jua:Regular',sans-serif] h-[57px] justify-center leading-[0] left-[390.5px] not-italic text-[36px] text-black text-center top-[126.5px] w-[313px]">
        <p className="leading-[normal]">Generated Report</p>
      </div>
      <div className="-translate-x-1/2 absolute bg-[#dc5e5e] h-[698px] left-1/2 top-[220px] w-[518px]" />
    </div>
  );
}