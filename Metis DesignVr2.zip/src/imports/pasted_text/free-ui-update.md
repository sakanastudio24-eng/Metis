Updated Free UI (Final Structure)

I’ll give you a clean Figma layout flow.

🟦 SIDE PANEL (Updated)
1. Score (Top)

Cost Risk: 72 (Moderate)

2. Quick Insight (NEW)

“High request count + AI usage detected”

3. Top Issues (max 3)
Duplicate API calls
Large images
AI usage detected
4. Session Estimate (NEW 🔥)

👉 THIS is your big upgrade

“Estimated session (5 pages): $0.01”

Small subtext:

“Based on typical usage”

5. Tech Stack (small)
Next.js
Vercel
OpenAI
6. CTA

👉 “Open Full Report”

🧠 Why this is strong

Now even the mini panel:

shows money
shows scale potential
feels valuable
🟪 FULL SCREEN (Updated Free)

Now we expand everything properly.

🧩 SECTION 1 — Overview
Score (big)
💸 Session Cost (NEW CORE)

“Estimated cost per session: $0.01”

Subtext:

“Based on ~5 pages per visit”

📈 Scale Preview (NEW 🔥)

“At 10k users → ~$100/month”

👉 This is HUGE for free value

🧩 SECTION 2 — Cost Drivers
💸 Breakdown
Bandwidth → ~$15
Requests / compute → ~$10
AI usage → ~$8

👉 This is where bandwidth lives

🧩 SECTION 3 — Problems (Expanded)

Each issue:

title
short explanation

Example:

Duplicate API Requests
“Same endpoint is called multiple times per load”

🧩 SECTION 4 — Known Stack

Expanded but clean:

framework
hosting
APIs
scripts
🧩 SECTION 5 — Session Assumptions (NEW)

Instead of hiding this in a form, make it visible.

Show:

“Assuming: 5 pages per session”

Button:

👉 “Adjust”

🧩 SECTION 6 — Adjust Panel (Inline or modal)

Simple inputs:

Pages per session
Traffic estimate
Hosting (optional)

👉 Updates:

session cost
monthly estimate
🧩 SECTION 7 — Plus Tease (Not Pro)

Rename your premium to:

👉 Metis+
Divider:

🔒 “Metis+ — Deeper Insights”

Show blurred previews:
“Why this costs money”
“Fix recommendations”
“Savings estimate”
“Multi-page scan (coming soon)”
CTA:
“Unlock Metis+”
“Fix this for me”
🧠 Key Improvements You Just Added
1. Session-Based Thinking

👉 MUCH better than page-only

2. Money Everywhere
session cost
monthly estimate
breakdown
3. No Need for Crawl Yet

👉 still feels powerful

🎨 Figma Layout Order (Clean Stack)

Vertical:

Header
Score
Session cost
Scale estimate
Cost breakdown
Problems
Stack
Session assumptions
Adjust panel
Metis+ section
🔥 What You Just Achieved

Without Pro:

users see money
users see scale
users understand risk
users feel insight
⚠️ Important UX Detail

Always label:

“Estimated”

👉 builds trust
👉 avoids “this tool is wrong” feeling

🧭 Final Answer

You updated free to include:

👉 Session cost + scale + breakdown

And saved for Plus:

fixes
explanations
savings
multi-page scan