🟢 Metis (Free — v1)
Core Experience
Single page scan
Instant analysis (no login required)
📊 Metrics & Output
Cost Risk Score (0–100)
Severity level (Low / Moderate / High)
💸 Cost Awareness
Estimated cost per session
Session assumption (e.g. 3–5 pages)
Monthly cost estimate (based on traffic input or default)
Scale preview
e.g. “10k users → ~$100/month”
🧩 Cost Drivers (Breakdown)
Bandwidth (estimated contribution)
Requests / compute
AI usage (if detected)
⚠️ Issues Detection
Top issues (3–5 max):
duplicate API calls
large assets
excessive requests
AI usage patterns
missing caching
🧠 Quick Insight

1-line summary:

“High request count and AI usage increasing cost risk”

🧬 Known Stack Detection
framework (Next.js, React, etc.)
hosting (if detectable)
APIs / AI providers
major third-party scripts
⚙️ Session Assumptions (Adjustable)

User can adjust:

pages per session
traffic estimate
hosting provider (optional)
🔄 Dynamic Updates
cost estimate updates based on inputs
scale estimate updates
🎯 UI / UX
Side panel (quick view)
Full panel (detailed report)
Fast, no friction, no login
🟣 Metis+ (Plus — v1.5 / v2)
Includes everything in Metis (Free)
🧠 Deep Explanations
“Why this costs money” per issue
clear connection to:
bandwidth
compute
AI usage
scaling behavior
🛠 Fix Recommendations
step-by-step fixes per issue
dev-friendly guidance
prioritized suggestions
💰 Savings Estimation
estimated savings per issue
total potential savings
📈 Priority Fix Order

ranked list:

“Fix this first for biggest impact”

📊 Advanced Cost Breakdown
more detailed cost modeling:
bandwidth vs compute vs API vs AI
clearer attribution of cost sources
🤖 AI Cost Analysis (Expanded)
cost per request (estimated)
cost per session
cost at scale (1k / 10k / 100k users)
📈 Scale Simulation
interactive scaling:
“If traffic increases → cost becomes…”
multiple scenarios
📄 Exportable Report
downloadable report (PDF or shareable view)
usable for:
clients
teams
agencies
🌐 Multi-Page Insight (v2 direction)
sampled page analysis (3–5 pages)
“site-wide estimate” based on sampling
💾 Saved Reports (Requires Auth)
history of scans
compare results over time
🧾 Account Features
login / profile
saved configurations
Metis+ status
💼 Optional Service Layer
“Fix this for me”
connect to Ward Studio services
🧠 Clean Mental Model
Metis (Free)

👉 Detect
👉 Estimate
👉 Reveal

Metis+

👉 Explain
👉 Guide
👉 Optimize